*****************************************************************

     The Elder Scrolls III
           MORROWIND: 
          T3 Helm and new weapons

	

		
*****************************************************************

Index:
1. Installation
2. Playing the Plugin
3. Notes on the Plugin


*****************************************************************

	1. INSTALLING THE PLUGIN

*****************************************************************

For TES3: Morrowind

To install the plugin, unzip the files into the Morrowind Data Files
directory. 


*****************************************************************

	2. PLAYING THE PLUGIN (including update notes)

*****************************************************************

From the Morrowind Launcher, select Data Files and check the box 
next to the T3helm_new_Weapons_Keening_sword.esp

This mod adds a new Helm based on the Terminator movie, A new Keening Longsword,
'Hero's Weapons" which are weapons that are weak and fast (more in notes on the plugin)


*****************************************************************


	3. NOTES ON THE PLUGIN

*****************************************************************

ALWAYS backup your savegame before using a new plugin. You use plugins 
at your own risk.

The new helm can be found in the arena pit, 3 nords wearing steel armour and the helm are standing there,
you must make the fist swing. (also in dwemer leveled loot)
The Keening Longsword can be found in the chargen barrel, (where you found fargoths ring) (also in dwemer leveled loot)
The "Hero's weapon's" can be found on the chargen room bench (where you found the first dagger) (also in dwemer leveled loot)

"Hero's Weapons" Notes:

These Weapons are to be used with Combat enhanced, they are weak and fast so that their strength comes from preforming combos
THEY SHOULD BE USED WHILE IN TRANCE OR RAGE, SOME MAY FIND THEM TOO FAST FOR NORMAL USE



==========================
No known conflicts so far.
==========================





If you do not like my plugin, i do not care. simpily uncheck it in the datafiles menu and there you go, no more problem.

Email me at something_in_you_I_Despise@hotmail.com with questions, concerns, bugs, or conflicts with other mods.

Also you can add me on MSN with the same address.