Hi and Welcome to Tel Nevar.

Tel Nevar is a complete overhaul of the Stronghold you can get from house telvanni. However Tel Nevar will work even if you havent completed this quest, just a lot of the dialoug will assume you have and not everyone will deal with you if your not telvanni.

IMPORTANT: the telvanni council house has been moved to the site of your strong hold so you can keep an eye on it.

Tel Nevar adds a town around the site of your stronghold and keeps the houses that were there before hand, however the tower itself is completely different. It adds a stilt strider to Molag Mar, and Mage guild travel to all the guilds. It also adds a few items of my own creation complete with original models, all you have to do is find them. Be warned though Tel Nevar is home to some very powerful wizards and there are few people who are push overs. If you dont like the effects on the items blank versions are available from your neighbourhood MudCrab Merchant.

To install just unzip the files into your morrowind Data folder

file structure:

morrowind\data\telnevar.esp
morrowind\data\meshes\Axe_of_the_champion.nif
morrowind\data\meshes\bluehat.nif
morrowind\data\meshes\magichat.nif
morrowind\data\meshes\mirrorshield.nif
morrowind\data\meshes\pearlsring.nif
morrowind\data\meshes\soulcleaver.nif
morrowind\data\textures\Aluminum Brush.tga
morrowind\data\textures\bluehat.tga
morrowind\data\textures\Dark Marble.tga
morrowind\data\textures\goldplate.tga
morrowind\data\textures\leather0.tga
morrowind\data\textures\magichat.tga
morrowind\data\textures\metalscr.tga
morrowind\data\textures\Old Weathered Boards.tga
morrowind\data\textures\Raw Emerald.tga
morrowind\data\textures\soulcleaveuvw.tga
morrowind\data\textures\Steel vault.tga
morrowind\data\icons\Axeofthechampion.tga
morrowind\data\icons\bluehat.tga
morrowind\data\icons\magichat.tga
morrowind\data\icons\mirrorshield.tga
morrowind\data\icons\pearlsring.tga
morrowind\data\icons\soulcleavericon.tga