You can get to Tel Branora by ship from Vivec.  The manor will be on the 
bridge to the city to your left.  The stairs are right on the bridge as other 
Telvanni houses.  The door will say "Tel Branora Manor"

This is my first real try with Telvanni architecture.  Hope you like it.
If you find any glitches, please email me at ladymage1@hotmail.com

Ravensong