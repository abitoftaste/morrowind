- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
PLEASE READ THIS README-FILE BEFORE INSTALLING THE MOD!!!
IMPORTANT INFORMATION, ESPECIALLY FOR THOSE WHO ARE USING VER. 1.0-1.1 OF THIS MOD!!!
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


Laura Craft Romance and Adventure mod - TRIBUNAL required
(Author: Emma, Movement script: The Other Felix, based on the original warping script by Grumpy )

Do you want some romance in your Morrowind life? Can you stand the thought of a Morrowind Laura Craft who sometimes acts and talks like a real life girlfriend? A Laura who will get mad at you if you try to bribe her, but will enjoy a pleasant gift or sharing a bottle of Mazte at a nice tavern? A Laura who also has her own problems - and an important mission to take care of?
  If the answer is yes, you might want to try this version of the Girlfriend Breton mod, including 17 quests, some of them very simple "lover's quests", some of them very rewarding, while others might be dangerous and time consuming. As time passes, you will be able to develope your relationship with Laura, for better or for worse. If you keep on playing as usual, the quests will probably not interfere very much with your ordinary gameplay. Laura will basically respond as before, but now and then, when you least expect it, she will bring up new subjects and new missions. This will only happen at certain places and during certain conditions, so there might be hours of gameplaying between each quest.
  Like in the Girlfriend Breton plugin, Laura Craft will still be your old time girlfriend, and you will find her outside her little cottage, just to the left of the bridge to Vivec Foreign Quarters. However, she will have a very much extended background story to tell you, and, unless your personality is very high, she will be more reluctant concerning her feelings towards you. You will probably need to do some dating or maybe fulfil some of her quests in order to convince her that you are "worthy" her devotion. (To those of you who have pointed out that it might be a good idea to start out with a rescue mission to find her - I'm sorry, but as Laura has already existed in the Morrowind world since october 2002, I've reluctantly decided against it. She already is the girlfriend of many Morrowind players. Although I agree with the idea, this just isn't Laura's story. Maybe I or someone else will create another Morrowind girl who has to be rescued in the beginning of the story, but this girl won't be Laura. On the other hand - I'm not saying that there aren't any rescue missions included in this mod).

Ver. 1.0:

NEW features:
- Laura literally talks to you when in dialog mode
- Laura will dance for you or sing a song if you ask her to do so.
- Laura will have her own way of dealing with you if you try to bribe her. And she will not be pleased if you try to use her ebony armor for your own protection.
- Just like a "real life" girlfriend, Laura will enjoy a nice gift or sharing a drink with you at a pleasant tavern.
- Laura will "know" if you have a weapon pointing at her, and this will influence the dialog.
- Laura will have her personal replies to nudity. 
- Laura will be able to communicate with you by telepathy.
- Laura will tell you about her current skills (i.e. you won't have to keep track on which of her skills you have been developing).
- One of Laura's "rewards" will make travelling together with her much easier.
- A little surprise is waiting for you in her basement. 

Other features (also available in the TRIBUNAL Girlfriend Breton mod)
- she's pretty -Laura has one of Rhedd's beautiful heads
- she's smart - she will have different dialogs in different places and in different situations. She has also taken up her studies, and can improve every skill - if you just have money enough to help her buy the expensive books. Everytime you give her money for studying, she will improve 1 point in any skill you choose. It's up to you if you want to make her a marksman or a spellcaster! If you ask her or if you just peek into her diary, you'll learn about her initial skills - and about her background story.
- she's an excellent kisser.
- she's an excellent runner, with an AiFollow script (developed by Grumpy and in this version enhanced by TheOtherFelix) that also allows her to really follow the player when flying.
- she won't get stuck in caves - the new AiFollow script will make her warp to the player.
- she won't get lost. Already at the beginning, she'll give you a ring that you can use to teleport her if you should ever get separated from her.
- companion sharing option allows you to give her whatever weapon, armor and clothes you choose, and she will help you to carry your stuff.
- some other suprises that you'll have to find out for yourself. 
Just as in previous versions, she's not only a good fighter but also a nice company. She is able to heal herself and she can provide you with some useful stuff along the road. She is also able to sneak, to cast a number of spells and to teleport to Mournhold, Ebonheart and Vivec.
If you start out with a low level character, you might find Laura's long blade skills a bit too impressing - you do want to do some fighting yourself, don't you? If so, just let her use any other kind of weapon where her abilities better matches the one of your PCCharacter.
THIS PLUGIN REQUIRES TRIBUNAL

Version 1.1:

NEW FEATURES:
1 - New combat options: You can a) order Laura to teleport back home if she gets severely injured b) order Laura to stay out of fight, until either she or you get severely injured (this is a brand-new approach, basically using dialog instead of scripting, which should NOT cause any errors in the enemies' attack behaviour)
2 - after really gaining Laura's affection (by solving a couple of her quests) she will show you her Really Very Special Dance and she will.... oh, no, you'll have to find that out for yourself.
3 - No more problems with the dialog window, that in previous version tended to occasionally re-open when you had just closed it.
4 - A backup-variable setting keeps track of how Laura's skills have been developed, as a guarantee (I hope) that she will not lose any skill improvements if you get long-term separated. 
5 - The step-aside-function, introduced by Dixon in his Companion Hilda mod, has been added. A very handy function whenever Laura is blocking your way.
6 - The initial greeting has been moved to greetings section 0, in order to make it show up even if you are playing as a vampire or a skeleton... (I can't guarantee that this will work out OK with every modder-made special-race, though)

Version 1.2:

NEW FEATURES:
1 - The attack-voices for the new combat options (flee if injured and stay out of fight) has been moved in order to function also if you are using GIANTS. (Thank you, Dinkum Thinkum, for helping me sorting this out).
2 - Laura can now be ordered to stay at one spot and COVER you during the fight. If you give her a marksman weapon (and remove her other weapons), her arrows will help you to kill the enemy. If you train her in marksmanship, she will be less likely to hit YOU instead of the enemy ;-) 
3 - The infamous Bethesda-bug that causes companion to take damage if passing through a door with slowfall active has been resolved. Same goes for the bug that causes companion to disappear if levitation is active when passing through a door. (Please note: you do NOT have to use the "Companionfriendly doors mod")
4 - Laura's swimming abilities have been improved - she is now as good at swimming as at levitating.
5 - Laura's voice greetings are now less repetitive.
6 - Laura will now automatically report if she is injured and needs healing.

Version 1.2.1:

Corrected one small but important bug in topic "time to make love".


PLEASE NOTE: This plug-in should be clean, it is tested + running smoothly together with a wide range of different plug-ins. HOWEVER Laura Craft is NOT compatible with and was never meant to be compatible with plug-in Boyfriend Indiana James.
The dialog-writing structure is intended to be made in a way that should avoid overwriting by other plugins. If another, newer, plugin should have similar topic/s (which usually causes the topic to disappear in the older plugin), the topic should still be available, although not highlighted. In order never to get the "key-topic" "together" overwritten, I have choosen to spell it "t0gether", which I hope you will not find too irritating.

-------------------------------------------------------------------------

CREDITS

--------------------------------------------------------------------------

First of all, I want to give my VERY SPECIAL THANKS to two fellow modders. Without their help and constant support, I would never have been able to release a companion mod with all the functions added to Laura:
GRUMPY, the developer of the warping movement and also a great modder friend. We have been constantly debating, arguing and laughing together for several months, and without his support, ideas and feedback, modding wouldn't have been half as fun as it is today.
THE OTHER FELIX, a great modder friend, who has added so much of his creativity and knowledge and so many good suggestions and enhancements to every aspect of this mod. Among many other things, he has taught me how to deal with the voice part of the dialog, he has created the telepathy script and he has further enhanced the levitating and swimming part of the movement script.
 
Thanks to Rhedd's beautiful heads, Laura Craft is prettier than ever before. (Rhedd's readme file is enclosed). 
The npc-movement in the companion-script is based on an idea from Reznod that has been developed by Grumpy, who has kindly offered me to use it in my plugins. Some additional enhancements, suggested by Devlor, has also been added. Finally, TheOtherFelix has made some extraordinary enhancements concerning particularly the levitating, swimming and levitating/fighting parts of the movement script.TheOtherFelix has also suggested a number of other vital scripts, for instance the telepathy script.
The skills-script is basically the same as TheLys has used in the "Give Your Orders"-mod.
The "Lover's ring" script is based on and reworked from the 18 destinations teleport ring script made by Scott Fischer.
The step-aside-function was introduced by Dixon in his Companion Hilda mod, and he has kindly offered me to use it in this mod.
I would also like to add my special thanks not only to Grumpy and The Other Felix, but also to GarryB (who has also corrected my lousy english grammar), Beardo, Devlor, Dinkum Thinkum, Fernelf, Sunsi and Robeast for giving me help, support and numerous of valuable suggestions.

----------------------------------------------------------------------------

INSTALLATION: 

----------------------------------------------------------------------------

ALWAYS MAKE A SAFETY COPY OF YOUR SAVED GAME BEFORE UPGRADING ANY MOD, THIS ONE INCLUDED!!!!

FOR THOSE OF YOU WHO ARE USING VER 1.0-1.1 OF LAURA CRAFT ROMANCE AND ADVENTURE MOD: no problems, just add this esp-file and keep on playing (Always make a safety copy of your saved game before upgrading any mod!!). 
PLEASE NOTE:
When you return to your saved game, Laura will probably NOT have the sharing option. In order to regain it, do like this:
a) Choose topic "my studies" and upgrade any skill (in order to activate the backup variable section)
b) Choose topic "t0gether", ask her to wait for you where you are. Close the dialog window.
c) Re-open dialog window. Choose topice "t0gether" and ask her to follow you. Voila! The companion sharing will return. (Should you at any occasion "lose" the sharing option, just do the same thing as I have just described).


FOR THOSE OF YOU WHO ARE USING A PREVIOUS VERSION OF GIRLFRIEND BRETON-plugin: In order to make this plugin work properly, you must first unload your stuff from Laura's cottage, leave Vivec, save game, uncheck the previous Girlfriend-plugin, load game and save game. Now, you are ready to add the new version to your gameplay.
Just UnZip to your Morrowind-library.
   Sometimes when removing an old plugin and adding a new one, a "ghost" from the old plugin might show up. If there should be a Laura duplicate, you will probably easily see the difference, as the "old" Laura is probably decapitated and have no "Laura-dialog". Call up the console when the decapitated Laura stands in front of you (see instructions below), make sure that you can see her ID-name at the top of the console (1AA_Laura). Write: disable 
Now, she should be gone for good. DON'T kill her, that might cause errors later on.
LAURA'S SKILLS: I'm sorry, but the money you have payed for educating previous versions of GIRLFRIEND BRETON will be gone when starting this mod. This is caused by the fact that I have altered her script and therefore I have also had to give her a new ID-Name (she is actually a totally "new" npc). What you can do is this: before disabling the old Girlfriend 2.1 version, call up the console (usually behind the ! or ' key, depending on which keyboard you are using) ingame while Laura is standing in front of you (you should be able to see her ID-Name at the top of the console). Check her current skill by using the command:
"1AA_Laura"->GetLongBlade (or whatever skill you want to check).
After adding the new version of the plugin, call up the console again while Laura is standing in front of you.
In order to "upgrade" her skills to what she used to have, write:
"11AA_Laura"->SetLongBlade 60 (or whatever you want to set it to). Now, Laura will have regained her "old" Longblade skill. Keep on doing this with the other skills that you have educated her in. 
When you have finished, you can check that what you have done has actually worked by using topic "my studies" and ask her to tell you about her current skills. 

FOR THOSE OF YOU WHO AREN'T USING ANY VERSION OF MY MOD:
Just UnZip to your Morrowind-library.

--------------------------------------------------------------------

TROUBLE SHOOTING:

-------------------------------------------------------------------- 

INSTALLATION:

1) LAURA HAS AN EXCLAMATION-MARK INSTEAD OF A HEAD: This is a rather common problem. When you unzipped the files, they ended up
inside a folder in your data files section, right? (This happens all the
time, as far as I know it's because you use an US/british version of Windows
while I use a scandinavian). And then you tried to drag each texture and
meshes manually into their right folders?
What you should do is this:
Move the new folder you got when unzipping to the desktop. Double-click on
it. You'll find one esp-file, one meshes folder and one textures folder
inside. DROP the meshes folder into your data files section. It should now
automatically merge with the existing meshes folder (probably you will be
asked a question about existing files, say yes to this). DROP the textures
folder into the data files section. It should also merge with the existing
textures folder. Move the esp-file to the data-files section. You're ready
to go, and now everything should work just fine.

GAME PLAYING:

1) When flying over the ocean together with Laura, you will of course sometimes be attacked by cliff racers. She will fight them, but after the fight she might be standing in the air, waving her sword, refusing to following you. This is caused by the angry slaughter fishes in the water below her; she wants to fight them, but can't determine their positions. You can either go down and start fighting them, yourself, and she will follow you. Or you can use the telepathy ring, to make her stop fighting and instead follow you.

2) If something should happen with the "companion sharing" option, you can always get it back by telling Laura that you want to be alone for a while. When you ask her to join you again, companion sharing will automatically be added. 

3) If you ask Laura to cover you during the fight, she will only use her marksman weapons if you remove her other weapons (as her longblade skill is higher than her markman skill). When asked to stay at one spot, she will continue doing so until you bring up the topic "our next fight again", and tell her to stop guarding that spot.

4) PLEASE NOTE: If you are separated from a companion for more than 72 game hours, the companion's skills will be reset back to initial value. I have tried to deal with this by adding and extra set of upgrading variables, but would still recommend that you try to pay a visit to Laura within these 72 game hours.

-----------------------------------------------------------

e-mail: emma9158@hotmail.com 
-----------------------------------------------------------

   
