Title: The Ghost
Creator:Afrodeeziak87 (logan_wexler5@hotmail.com)
Type:Birthsign and Class
Description: This mod adds a new birthsign and class to morrowind called The Ghost. Its pretty much my favorite attributes and skills put together so I dont have to customize anything ever again (unless I learn to like magic)

The Class does the following

Primary Attributes: Agility and Willpower
Specialization: Stealth
Major Skills: 
  Sneak
  Acrobatics
  Light Armor
  Long Blade
  Marksman
Minor Skills
  Block
  Mercantile
  Short Blade
  Security
  Unarmored

The Birthsign has the following
Abilities:
The Ghost's Prevention
  Resist Paralysis 75%
  Resist Normal Weapons 100%
  Weakness to Magicka 25%
  Reflect 25% 
Powers:
Blanked of Darkness:
  Chameleon 100% on self for 120 seconds
  Night Eye 50 points on self for 120 seconds
  Drain Attribute: Speed 50 points on self for 120 seconds
  Drain Skill: Athletics 50 points on self for 120 Seconds
The Ghost's Lockspitter
  Open level 100 on touch

Note: There is no real birthsign constellation image. I simply included an old one an edited it to appear blank. If anyone can create a ghost constellation for me, please contact me.

