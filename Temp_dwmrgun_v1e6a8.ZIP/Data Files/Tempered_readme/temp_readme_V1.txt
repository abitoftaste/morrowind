*********************   Dweomer Pod Launcher *******************************
************* Bloodmoon & Tribunal Expansions Required *********************


 This mod adds a Dweomer Pod Launcher and Forge Bane Fungus to Morrowind. Thirteen Pod Launchers have been inserted into the game. They can be found where most Dwemer artifacts are found (hint, hint).     Over one thousand Forge Bane Fungus have been added to appropriate interior cells to supply ammunition for the Pod Launcher. 
 
  Items added are named as follows in the construction set:

Temp_dwmr_gun : This is the Dwemer Pod Launcher. An artifact used to launch spore pods at the enemy. It uses technology similar to the steam golems. A source of steam is magically generated within the weapon and used to power the projectile. 

Temp_dwmr_shell : These are the spore pods used as ammunition. They come from a fungus that grows in hot underground areas and seem particularly fond of Dwemer ruins. Spore pods have a nasty habit of exploding when disturbed. Releasing a toxic cloud of fungus spores. Some spore pods are more sensitive to impact than others, making harvesting them a tricky endeavor. When launched from a pod launcher they do kinetic damage similar to a normal bolt. They will also explode upon impact and create a poisonous cloud of choking spores.

Temp_dwmr_pods : Forge Bane Fungus.

Temp_dummy : This is a dummy object used by the ammunition script. Do not use this in game.

Temp_dwmrgun : script used on the pod launcher to keep inappropriate ammunition from being used.


************************ Files and where to put them ************************************

dwmr_gun_v4.nif: Nif file, placed in the data files/meshes/tempered folder.

dwmer_fungus.nif: Forge Bane Fungus, placed in the data files/meshes/tempered folder.

dwmr_shell.nif: Spore pod.  Place in the data files/meshes/tempered folder

dwmr_gun_icon.dds: Inventory icon, placed in the data files/icons/tempered folder.

dwmr_shell_icon.dds: Inventory icon, same as above.

Temp_dwmer_gun.esp: Place in the data files folder.

 All meshes and textures are my original creations. Textures have been compressed into the nif file for easier distribution. If you would like an untextured mesh for your own modding projects, email me at tempar2000@yahoo.com and I will send them to you.


**************************End Users License Agreement*************************

 You are allowed to use, distribute, modify, plagiarize, criticize or delete this mod as you see fit.

*****************************    Credits   **************************************

 Special thanks to elegiac for the ammunition script.

 esp Cleaned with TESTool by ghostwheel


