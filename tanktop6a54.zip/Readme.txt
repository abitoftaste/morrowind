Tanktop
creator Dereko

This mod adds a female tanktop compatible with better bodies 2.1 (www.psychodogstudios.net)
You will find the tanktop sitting on top of the counter in front of the merchant in the clothing store
in Caldera.

To Install

Just unzip or drag and drop the "Data Files" folder into your Morrowind folder, Then Check the tanktop mod in your
data files of course.


This can also be used as a modders resource, feel free to use the mesh in your own mods or to retexture it
please give credit in your readme files.

PLEASE READ************

do not drag and drop or extract the texture file in the "modders resource folder" included in this zip file
this file is only to be used if you want to retexture your tanktop

forced 1 bit Alpha channels have been enabled on the nif if you wish to create transparent parts.


This mod has been cleaned with testool and contains no known errors or bugs


