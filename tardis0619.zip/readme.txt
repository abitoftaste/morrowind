Morrowind TARDIS Mod

I hope I've gotten all the parts into the .zip file.

This mod puts a TARDIS into the game of Morrowind.  It will first show up
in Balmora between the fighter's guild and the 8 plates.  If you walk down
that street, you'll trigger it.  

Once you find the TARDIS, you can go inside.  Being a TARDIS, it's a lot
bigger on the inside than the outside.  The interior of a TARDIS exists
outside normal space.

Inside you'll find a control console (kindly modeled for me by Lady Eternity)
on the right side of this console are some switches which allow you to operate
the TARDIS and use it to travel around Morrowind.

There are also some large rooms which are largely unfurnished at this point.

This is basically a beta version of the mod and I'm only looking for
feedback as to how it works.  Did I get all the models and textures, etc.

There's a note inside the TARDIS with credits as to who made some of
the models and stuff.  And a better explination as to what a TARDIS is.

Things I already know...

* The thing in the center of the console can't be stopped.  Technically it
  should only bounce up and down while traveling.  Also the transparent tube
  (hexagon) and the part inside don't move together.  Lady E. had never
  seen Dr. Who before and all she had to go by were still photos and my
  description.

* I think I need to put the swimming pool in it's own cell.  Either that or
  there needs to be a way to tell a cell to have water that's still and 
  doesn't make noise unless you jump in and swim. :-)

* The control room has some cracks between some of the wall panels.
  building a hexagonal room is hard because you can't use the snap grid
  to force things to line up.

If you find any problems, let me know. 


dwilliss@inetnebr.com
dwilliss in the Morrowind forums

Website:  www.schaeferfamily.net/Morrowind/
