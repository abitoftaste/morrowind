==============================================
Telperion - Ascadian Isles Tree House
By Calislahn
==============================================

INDEX:

-> Requirements
-> Version History
-> About this mod
-> Installation
-> Playing this plugin
-> Known Bugs & Issues
-> Incompatibilities & Save game warnings
-> Credits & Usage


==============================================
REQUIREMENTS:
==============================================
This Mod requires both Bloodmoon and Tribunal.

==============================================
VERSION HISTORY:
==============================================
V.1.02 - The script I had attached to the feyblade was preventing it from being picked up if the player dropped it.I have removed the script and the Journal entry added by that script.Thanks to biter for pointing this out to me.


V.1.01 - There were a couple of rogue textures included with version 1. These have been removed and I have also updated the rich bookshelf, desk and table by KWShipman so they use the textures shown in my screenshots instead of the default swirlwood textures.They are renamed so will not overwrite any textures replacers you may be using.Thanks to Khallaza Productions for those textures.

If you have version 1 installed and do not normally use the Visual pack the textures that accidently got included were:

Tx_wood_swirlwood_trim_04.dds
Tx_wood_swirlwood_trim_05.dds

I would reccomend removing these from your texture folder and replacing them with the ones from your usual texture pack, sorry for the inconvenience :)

==============================================
ABOUT THIS MOD:
==============================================
Using Dongle's Tree House model Telperion is located on a small island south of the Telvanni Canton in Vivec.To get there first head east from the canton then once you reach the path turn south, this will take you across a small wooden bridge. Once you cross the bridge head slightly south west and you should find it. 
If you have my Dryad Dress mod installed and have visited Xera before, Telperion is just behind her location. This mod does not conflict with my Dryad Dress mod as I made sure of that.

The Tree house contains:

Lower Level - Seating, Dining and Kitchen areas.
Middle Level - Alchemy Lab and Storage.
Upper Level, Bedroom, Bathroom and Lounge areas.

Storage:

There are several different types of storage containers in the house including,
 
Large Chests - 26 encumbrance 1000
Small Chests - 3 encumbrance 250
Hutchs - 12 small and one large custom hutch encumbrance 500
Shelving - 6 open bookshelves (lower shelf of each contains three chests) and four closed bookshelves.

The Alchemy Lab has a working alchemy sorter.Nissa will happily sort your ingredients into their respective jars, she doesn't do custom ingredients of course.

I have not included any mannequins but there are spaces where they can be placed. There are quite a few placeable mannequin mods available including my own Better Bodies ones.

Teleport Ring - This will bring both you and any companions with you back to the Tree House.

The following exterior cells were altered slightly by this mod:

Ascadian Isles 5,-12
Ascadian Isles 5,-13
Ascadian Isles 6,-12
Ascadian Isles 6,-13
Isinfier plains -22,21
Isinfier plains -23,21


===============================================
INSTALLATION:
===============================================
Just extract to your Morrowind\Data Files directory.


===============================================
PLAYING THIS PLUGIN:
===============================================
To gain access to Telperion there is a small quest. To start this travel to the island where Telperion is located and in the garden you will find a fairy inside a shield. Her name is Nissa and it's up to you to free her from her entrapment. To find out how just activate the shield and you will recieve a cryptic clue.

This is just meant to be for a bit of fun and is not a major quest. I just felt it was nicer to have to work for the house than just being able to move straight in.

I would reccomend you be at least level 10 before attempting this quest, you could try at a lower level but be warned you will be travelling through Solsthiem at one point and have to fight Spriggans which can be tough so go prepared!

If you get stuck on the quest and can't find the location in Solsthiem please refer to the spoiler readme included with this file.
===============================================
KNOWN ISSUES OR BUGS:
===============================================
The return teleporter from the grove doesn't always show the loading area box, if this happens don't think your game has frozen just give it a minute and you will be back where you started by the first one.


===============================================
INCOMPATIBILITIES & SAVED GAME WARNINGS:
===============================================
Always make sure that you backup your existing savegame before use.

There are no known incompatabilities with this mod.

This mod was cleaned with the Enchanted Editor.

===============================================
CREDITS & USAGE:
===============================================

There are quite a few people to thank here so bear with me :)


Dongle - for the  wonderful Tree House mesh, Canopy Bed and his Water Mesh Pack.

Regan - Celestial Lily and Fairy statue plus the ground mesh used in the grove.

Korana, Mighty Joe Young and Lochnarus - for the models used from Korana's furniture resource pack including, the fireplaces, glass table, hutches (small and large) amoir, weapons cabinet and glass cabinet, sofa's and small table.

Korana - canopy bed texture.

Lord Yig - Rugs and Tapestries.

KWShipman - rich table, bookshelf and desk plus the alchemy resource.

Monica21 - for helping me to get hold of a copy of that alchemy resource.

Silaria - for her lovely pottery mod.

Cait - the egg and meat meshes used in the kitchen.

Lady E - for the fairies and the fruit models.

Pheobe - the green and pink planters

Robearbebil - for the beautiful Feyblade.

Barabus - kitchen range, poker, kettle, coal skuttle and saucepan.

Lady Luck - soap

Kiriel - for the chairs in the lower level seating area and the stone basin in the bathroom.

JJS - for the alchemy storage jars.

Daduke - for the key to Telperion.

Starboi - for his Earth Ring used for the teleporter.

Emma - for letting me adapt her VTA travel script for the teleport ring.

AnOldFriend - for the Fairy wings used on the statue.

Mental Elf - for his brilliant TESFILES utility, great for unorganised modders like myself.

Carnajo, Khallaza Productions and Qarl - I have applied textures both from Carnajo's Imperial pack and the Visual packs to the treehouse interior as they gave it a nice warm feel in my game and I wished everybody to have the same. The textures I used have all been renamed with a prefix so if you do not use those packs your normal game wont be affected by them.

And of course Bethesda for the game.

If I have missed anybody out I apologise now and say thank you :)

-------------------------------------------------------------------------

The following things were made by me - face cloth in bathroom, kitchen storage jars, redware teaset and frying pan. Other than the face cloth the other models are all available in my kitchen mod and are free to use by anybody as long as I get credit as is the face cloth.

-------------------------------------------------------------------------

And finally,

Big thanks to Regan for his help and also his wanting this house for himself, along with Mebyon, otherwise it would have never got released!

And also for Beta tesing the mod for me.
 
Also thanks to everybody at Perceptual Motion for their continued help and support :)

=============================================
SPECIAL NOTES
=============================================
Although this mod will be on both my website and other mod hosting sites, such as TES4 and TESMods to name just two,if for any reason this mod becomes unavailable you have my permission to upload it to a mod hosting site intact as is.

If you are the owner of a mod hosting site and wish to upload this mod please feel free to do so.

=============================================
CONTACT
=============================================
EMAIL: calislahn@lycosmax.co.uk
WEBSITE: http://www.calislahnsmods.co.uk/index.htm