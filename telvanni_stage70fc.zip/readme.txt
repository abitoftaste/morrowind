                                          TELVANNI STAGE MOD BY REDZOMBIE125
---------------------------------------------------------------------------------------------------------------

Installation:  Put the EX_T_stage_01.nif file into the Morrowind/Data Files/Meshes/x directory.
	 The textures are from Morrowind itself, so you shouldn't have any problems with that,
	 but just in case, the textures (included) should go in the Morrowind/Data Files/Textures directory.

This is a modder's resource, so use this however you want. If you have any questions, e-mail me at 
RedZombie125@gmail.com.

---------------------------------------------------------------------------------------------------------------

