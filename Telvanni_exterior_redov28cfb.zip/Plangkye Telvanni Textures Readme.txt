.........................
Telvanni Hi-Res Textures
by Plangkye
plangkye@comcast.net
.........................


Telvanni architecture is now hi-res, and stays true to the original Bethesda design as well as one could expect with textures generated from photograhs.

To install, extract the textures into your Morrowind/Data Files/Textures directory. Make sure you back up your textures first, as you should with all texture replacers! The textures from the previous version of this mod are located in the "Old Textures" folder if you prefer them, but they are less realistic.

Redistribute this package as you will, as long as nothing is added or removed, including the readme. If you use my textures in your own mod, give me credit. All the textures are my own work, generated from photographs collected from various stock sites.

~mipmaps added by X-Calibar