Telvanni exterior change
by ddfields
ver. 2.0


This is an esp-less mod that changes the exterior of all (I repeat all) Telvanni structures in Vvardenfel and Tamriel. I wanted to add a little color to the Telvanni structures and flora and to also make the housepods with more than one exterior texture choice. Since Tamriel is heavily Telvanni, most all my screenshots were taken there. There are more screenshots included with the file as well as the screenshots shown here. This will give you an idea of how Sadrith Mora, Tel Aruhn, Port Telvannis, etc will look if you choose to load these changes.

I have included only the meshes needed for the specially named textures and the textures files that have changed. All other textures are are from Plangkye's Telvanni mod and are not included. 

If you already have Plangkye's Telvanni Textures mod as I do, you will have the same interior textures and the same slavepod textures as shown in the screenshots. Plangkye's interior textures work well with my exterior textures and an example can be seen in the Port Telvannis dock shots. If you do not have her mod, it is available for download here at Planet Elder Scrolls, should you wish to use it.

The doors(Dragon door and housepod door) are reworked textures from DK_Got textures resource files also found here. Some of his wood, glass and metal textures were also used to help create some of the textures I did.
The wood, bark and roots for the towers, manors and councilhalls as well as the ramps and stairs are from Plangkye and have been reworked as well.
The housepods, mushrooms and Telvanni parasols are created from jpg files found on the internet of various mushrooms and fungi. None of the images used were watermarked and were free to use.

Be sure to read the enclosed Read_me and Meshes/Textures files for more info.

INSTALLATION:
------------------------------------------------------------------
IMPORTANT! I strongly recommend that you backup your texture files before proceeding. You can back up your meshes folder as well. This is the safest and easiest way to go back if you change your mind.

You can unzip the Meshes and Textures folder directly to your Morrowind\Data Files folder and answer yes to any request for overwrites.
You can also unzip the folders to a temp area and copy/paste each folder to the Morrowind\Data Files folder and again answer yes to any request for overwrites.

Change in version2.0 - Optional textures folder added. Just copy/paste the texture you want to use to the
	DataFiles\Textures folder in your Morrowind directory. Answer yes to overwrites.

UNINSTALL:
-------------------------------------------------------------------
As mentioned above, it is a good idea to backup you meshes and textures folders. If you wanted to go back just copy your texture folder back and answer yes to all overwrites.
If you backed up your meshes folder, you can delete the "x" and "d" subfolders and then copy your backup over answering yes to all. 
There are other methods you can use, the choice is yours.
 I have included a list of all meshes and textures used. You can use this to delete or overwrite each individual file, but you would still need to copy your old textures and any meshes back in. So did you back them up?
If you have Plangkye's UV Corrected Telvanni meshes, you can simply reload those after deleting my meshes.

Versions:
-------------------------------------------------------------------
1.0 - May not be updated, but you never know.

2.0 -  Reworked most all textures to get better detailing.
          Changed textures for podbud 02.
          Added glowmap for podbud 03.
          Added glowmap to Council hall.
          Added optional textures folder with the following:
	Texture for all exterior doors using tx_atronachfire_face.dds as seen in Darker Ulvirith.
	Texture for optional council hall with glowmap - from Bethesda original council hall texture.
	Optional texture for symbol stone door - from reworked Bethesda orginal tga. 

Credits:
-------------------------------------------------------------------
Plangkye for her Telvanni Textures mod and generously allowing the use of her textures. (see included readme file)

DK(Dempcey Knight) for the Got Textures resource and the use of his textures. (see included readme file)

Planet Elder Scrolls for allowing people to share their mods.

Bethesda Softworks for the greatest game ever.

To anyone out there that took the time to share pictures on the web.

Disclaimer:
-------------------------------------------------------------------
You are free to use any of the textures done by me as long as I am given credit.
You can redistribute this mod but please keep it as is-no changes and include all the readme files.

Contact:
-------------------------------------------------------------------
Hope you enjoy it if you use it.
Any questions or problems, I can be reached at Yahoo mail
dracotrain@yahoo.com or post a comment here at PES.
