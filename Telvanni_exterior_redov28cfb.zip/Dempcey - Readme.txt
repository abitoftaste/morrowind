^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^

Got Textures 1
Dempcey Knight !DK Texture Collection 2004 - 2006
Dec 20th 2006

^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^

REQUIREMENTS:

95% of these textures are in JPEG format high Res, however to save others time and because
some of these textures require layers and or transparcies they are in DDS, TGA and mostly
PSD formats. So you will need some sort of photo editing software such as Photo Shop 7.
Other than that all you need is a bit of imagination^^

^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^

WHAT YOU WILL GET:

I broke the textures up into six ZipGenius packages because they are so large.


Got Tetures 1  (115Mb)

Amor		14
Bark  		78
Blocks		399
Buildings	35
Cloth		226
Coral		19
Crates		37
Doors Windows	123
Egyptian	51


Total =		982


Got Tetures 2  (123Mb)

Eyes n Teeth	77
fay n !DK	129
faylynn		52
flamel		34
Floor Bricks	55
Floors Earth	130
Floors Cobble	39
Floors Metal	30	
Foods		73	
Glass		97


Total = 	716 Textures


GOT TEXTURES 3	 (122Mb)

Granite	        37
Grates		17
Images --->	
*Animals	24
*Books		36
*Dishes Wears	12
*Earth		30
*Jewelry	35
*Lovers		24
*Maps		17
*Men		104
*Misc		23
*Paper		9
*Pic Frames	28
*Rugs n Taps	128
*Signs		20
*Women		75
Ishan Veet	62
Labels		121
Marble		58
Metal		138
Pattrens	63
Plaques		85


Total =		1146 Textures


GOT TEXTURES 4	 (204Mb)

Pillar			5
Plant Life		128
Rock			110
Roofs			34
Set0			7
Set1			22
Set2			33
Set3			24
Set4- purple		16
Set5- white		35
Set6- bad		24
Set7- red org		11
Set8- pink white	14
Set9- small brick	13
Set10- red		13
Set11- grey		49
Set12			224


Total =			762 Textures



GOT TEXTURES 5	 (118Mb)


Skins			14
Transparents		48
Trim			195
Wall Art		4
Wall Misc		246


Total =			507 Textures


GOT TEXTURES 6	 (120Mb)

Wall Brick		80
Wall Plaster		11
Wall Rough		158
Wall Smooth		86
Wall Stone		184
Wall Tile		16
Water			40
Wicker			20
Wood			181


Total =			776 Textures
Grand Total =	       4889 Textures

^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^
SPECIAL THANKS TO:

Planet Elder Scrolls
faylynn
Ishan
Veet
Shannon
koana
unDuLe
Qarl
Thanks all^^

-------------
Installation
-------------

Extract the archive any where you want onto your computer. As this collection is almost
two years old I suggest you look through the textures, pick and choose and delete what you
don't want after installing as there is a also a good chance you already have some of
these too.

^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^
***************************************************************************************
NOTES:                                                                                *
                                                                                      *
STRONG NUDITY within the MEN Folder, LOVER Folder and WOMAN Art Folder!!!             *
                                                                                      *
^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^
^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^

PREMISSION:

If there is a !DK_ in front of a texture it is mine and you're welcome to use them as you
see fit. Most of these textures came from the web, misc pictures I just clicked and saved
and do NOT require premissions.
HOWEVER....

WARNING!!! WARNING!!! WARNING!!!

DO NOT EVEN THINK ABOUT SELLING OR PUBLISHING WITH THE INTENT OF SELLING OF ANY OF PHOTOS
IN THE MEN,LOVER and or WOMEN FOLDERS!!!THEY BELONG TO AN ARTIST. I STRONGLY SUGGEST YOU
USE THEM FOR YOUR OWN PERSONAL WORK IN YOUR OWN MODS NOT TO BE PUBLISHED PERIOD. I ONLY
USE THEM FOR TAPESTRIES AND PAINTING WITHIN MY OWN PERSONAL MODS.

^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^
^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^_^

I can be contacted at: Dempcey_Mods@yahoo.com
 