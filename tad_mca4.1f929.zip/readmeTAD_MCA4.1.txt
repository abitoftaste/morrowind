==============================================
MCA4.1 compatibility patch for Taddeus Balancing Mods
version 1.0
"created" by StanRex
==============================================

INDEX:

-> Requirements
-> About this mod
-> Installation
-> Files and their Proper Directories
-> Known Bugs & Issues
-> Incompatibilities & Save game warnings
-> Credits & Usage


==============================================
REQUIREMENTS:
==============================================
Morrowind Comes Alive 4.1 by Neoptolemus
Taddeus Armor and Weapon Balance mods, by Taddeus


==============================================
ABOUT THIS MOD:
===============================================
This mod was created using the excel sheets provided by Taddeus.

===============================================
INSTALLATION:
===============================================
Extract all .esp and .esm files to the Data Files directory.
Extract all .nif Files to the Data Files\Meshes directory.




===============================================
FILES USED AND THEIR PROPER DIRECTORIES:
===============================================

~~~~~~~~~~~README FILE~~~~~~~~~~~~~~
readmeTAD_MCA4.1.txt


~~~~~~~~~ESP & ESM FILES~~~~~~~~~~~~
\Data Files\TAD_MCA4.1.esp



===============================================
KNOWN ISSUES OR BUGS:
===============================================
none yet :) But email me if you find one! I ll try to release a patch as soon as possible

===============================================
INCOMPATIBILITIES & SAVED GAME WARNINGS:
===============================================
Always make sure that you backup your existing savegame before use.


===============================================
CREDITS & USAGE:
===============================================

Feel Free to use any of the resources I provided in this plugin, but give credit to me where it is due.
Kudos to Glassboy for his readme template


EMAIL: stanrex@gmail.com

