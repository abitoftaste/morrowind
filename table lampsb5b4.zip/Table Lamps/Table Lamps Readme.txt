Table Lamps by swordsman5

I don't know if this has already been done, here are a bunch of tables which are carryable, there are 9 different types,
place them where you want them and they give off light in different colours. Don't like the effect? then pick it up and 
try another one! 

There are no inventory icons so you'll have to make do with the default smiley face...at least they are easier to find!

The tables are in a crate just inside the door at the top of the Seyda Neen Lighthouse .... balanced on the barrels there.

Cleaned with TESAME.

Use these how ever you want, If you want to put them in your mod feel free to do so.

Enjoy.