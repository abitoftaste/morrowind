--------------------------------------------------------------------------
  Tel Magus -- the ultimate mage tower!

  http://www.xs4all.nl/~dleijen/morrowind.html
--------------------------------------------------------------------------
Author:
  Aragon

Credits:
  * Chris Janosi (alias: mr Phantastik) for the original armor mannequins.
  * Bilbo Willowtree for the texture and model of the Robe of Galerion.    
    (This comes from the fantastic "The Black Mill" plugin).
  * An unknown artist for the glass display cases. I got them from Abu's
    Retreat by Phoebe. She writes: "I know I got this script from somewhere 
    but can't for the life of me figure out where. If you recognize it 
    please let me know so I can give you credit."
        
Version:
  1.0, 18 Jan 2005
 
Installation:
  Unzip everything in "Program Files\Bethesda Softworks\Morrowind\Data Files".
  Make sure you unzip with the "folder names" option on, so that icons 
  go the icons directory, meshes to the meshes, etc.

Playing the plugin:
  From the Morrowind Launcher, select "Data Files" and check the box 
  next to the "TelMagus.esp" file.

  If you want Tel Magus to be in the Grazelands, just north of Zainab camp, 
  check the box next to the "TelMagus-Grazelands.esp" file. Or, if you want 
  Tel Magus to be just south of Ebonheart, check the box next to the 
  "TelMagus-Ebonheart.esp" file. Of course, you should only select one 
  these!

  If you have both Tribunal and Bloodmoon installed, you should also check 
  the box next to "TelMagus-Ingredients-TB-BM.esp". This adds an exotic 
  ingredients crystal that can also sort ingredients from those expansions.

Description:
  Telvanni style tower that is great for mages and fighters alike! On the 
  one hand, it is a grand house with an indoor waterfall and a tree 
  spanning over four floors, but at the same time it has a cozy and rustic 
  atmosphere. I tried hard to make this a realistic and practical house, 
  with quick access to the bed room and teleportation chamber. There is 
  also a great display room with armor mannequins and glass display cases. 
  Furthermore, the alchemy room has a very convenient crystal that 
  automatically puts all your ingredients in a special ingredients chest. 
  There is an outside balcony with a fire pit and an underground cave where 
  the waterfall ends. Last, but not least, the top floor has a secret entry 
  (can you find it?) that holds a return ring and a powerful staff for 
  mages.
  
  The entire interior is made from a single cell, so there are no 
  inconvenient load times when you go through a door. This also gives a 
  highly three-dimensional feel to the tower, with `peek throughs' to other 
  floors.

Revisions:
  1.0: 
    Initially released version.
