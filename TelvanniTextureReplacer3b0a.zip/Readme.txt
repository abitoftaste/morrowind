Telvanni Texture Replacer
by Carnajo ( aka Petro )

This mod tries to makeTelvanni Cities, such as Sadrith Mora and Tel branora look a bit more interesting and detailed, with better textures, adding variety, without changing the feel of morrowind.
Compatible with KP VIsual Pack and Visual Pack XT (in that you won't have problems and can use them together if you wish, may overwrite some of those files)

INSTALLATION

All you have to do is copy all the files to your morrowind\data files\textures folder.
Copy the folder CA Telvanni Extras to your morrowind\data files\textures folder.
Should be compatible with everything, since there is no esm or esp file. It will alter any other previously installed mods which also alter the textures of Telvanni City exteriors or interiors, such as Fantasy Colored Morrowind. Replaces some textures from Morrowind Visual Pack, this won't cause problems.  If you prefer these, and wish to run the two packs together then install this AFTER the Morrowind Visual Pack, Fantasy Colored Morrowind, or any other texture pack. Just click yes when asked if you wish to overwirte the original files.
If you install any mod that overwrites these and you wish to revert to my textures, simply re-copy all the files to your textures folder.

COLOUR VARIATIONS

This also creates a folder called "CA Telvanni Extras" in which are three other folders, "Brown", "Green" and "Red". In these three folders is a dds file. This file replaces the texture of the Telvanni towers' floor and tubes, it is also found in the Telvanni council. I have created three colour variants of this texture.

To change colours:
Open the folder of the colour of your choice, right click the file and select "copy". Go to your Morrowind\Data Files\Textures\  folder right click, and select paste, click yes to overwrite the file in the folder. 
Do not worry, you can revert back to that one by repeating this procedure with whichever colour you please.
The default colour (i.e. the one which is installed automatically) is brown since it is the most natural and closest to the original. Feel free to swap as you please, it won't mess up your save game.

UNINSTALL

To remove, just delete the files from your textures folder. An easy way to do this is to extract this pack to a temporary folder, select all then copy. Got to your morrowind\data files\textures folder and choose paste, since this was already installed you will be asked if you wish to overwrite the files, select yes. Now all the files of this pack will copy, after which they will all be highlighted, now just select delete.

CREDITS

Three textures which are included in this pack (namely Tx_emperor_parasol_01.dds, Tx_emperor_parasol_02.dds and Tx_emperor_parasol_03.dds) are from the KP Visual Pack, so a thank you to the Khalazza Productions team involved with that pack, namely  Zuldazug, Raptre, Lord Gabryael and Ayse.
I strongly reccomend installing the KP Visual Pack alongside my packs (install KP pack first, then install mine, click yes to overwrite any files)
KP homepage can be found at http://khalazza.production.free.fr/

CONTACT, and UPDATES

My homepage can be found at http://home.tiscali.co.za/~31003603/
(copy and paste that into your browser adress bar)
Please feel free to check it for any updates to this mod, as well as details regarding this or any other of my mods.
One can reach me by sending a Personal Message (PM) to me, Carnajo, at the Elder Scrolls Forums ar http://www.elderscrolls.com