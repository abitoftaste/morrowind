@========8[-< Telvanni Robe for Morrowind -------------->
@========8[-<------- By MP*Canus ----------------------->

For the discerning magic-user who doesn't wish to look 
like a pansy in a pink and yellow robe, comes the Tevanni 
Robe! Made by Telvanni-owned slaves in a hidden sweatshop, 
these robes combine the finest materials and workmanship 
you'll find anywhere in Morrowind. Ready to enchant at 
finer clothiers across Vvardenfell!

(Note: There's a reason for the price. See if you can 
discover it. :D)

@========8[-<------------------------------------------->

To use: Extract the zipfile to your Morrowind folder
(e.g. C:\Program Files\Bethesda Softworks\Morrowind).
keeping pathnames intact. Then load up the Morrowind 
launcher, and click the box that says Telvanni Robe.

Start up your game, and yer all set. :)

@========8[-<------------------------------------------->

Credits to Bethesda for not only the mesh I reskinned,
but also the best damn RPG in existence, BAR NONE. :)

@========8[-<------------------------------------------->

Any questions, comments, etc., should be posted on the
official Morrowind mod forum located at:

http://www.elderscrolls.com/ubbthreads/postlist.php?Cat=&Board=UBB7&PHPSESSID=