Readme - Tel Uvirith Underground 1.1

This is the same mod as the original Tel Uvirith Underground, exept I forgot to mention one of the master files required; the NPC replacer by ZerotheHero. 
You can download this mod from http://www.khalazzaprod.fr.st/
If someone knows how to make the mod work without this master file, please e-mail me. 

I also added some new nice spells and weapons, to make up for this. Nothing uber, of course, that'll have to wait until I get more feedback.... :c)
I also added this nice readme file, even though I really doubt you need it.  
This mod does not conflict with Uvirith Unleashed. I haven't tried the other Uvirith mods, but since the entrance is situated in the tower dungeon, 
any mod removing this cell will make this mod unaccessable. 
If there's any interest, however, I can try to make versions that work with the other Uvirith mods too. 


To install this mod: Simply put the plugin data file in the "data files" folder of your morrowind directory.
If you already have the first Tel Uvirith Underground mod, simply replace it with this new one.

If you have any feedback, email me: mandana_84@hotmail.com

Thank you for downloading this mod! I hope you enjoy it ... :c)