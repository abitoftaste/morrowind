------------------------------------
The Elder Scrolls III               \
      Morrowind                      |
-------------------------------------
Tainted Cottage
**
By Josh "Devrith" Creech
--------------------------------
*Note* This mod was developed and tested with version 1.2.0722 of Morrowind. It will
probably work fine with other versions, but was only tested on the version above.

This mod has been cleaned using TESAME.
--------------------------------

Index:
1. Installation
2. Playing the Plugin
3. Your Saved Games
4. Bugs/Conflicts/Issues

---------------------------------

1) INSTALLING THE PLUGIN
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 To install the plugin, simply unzip the files into your Morrowind/Data Files
directory.
-----------------------------------------------------------------------------


2) PLAYING THE PLUGIN
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 From the Morrowind game launcher, select Data Files then locate TaintedCottage.esp and check
the box next to it.

  This plugin adds a small cottage near the Stilt Strider port in Vivec. At first glance, it seems like a perfectly
normal cozy little cottage.. but there once rumors of Dagoth Ur worshipers living there.
-----------------------------------------------------------------------------


3) YOUR SAVED GAMES
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 This plugin will not invalidate your old saved games. However, if you disable this plugin and
load a game it was active in you'll have to click through all those annoying error messages, but
everything should work fine.

*Note* To be safe, you should always backup your files before using any mod. Only as a precaution
incase you ecounter any problems with the mod.
-----------------------------------------------------------------------------


4) BUGS/CONFLICTS/ISSUES
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 None known of.

[If you find any problems with this mod, please email me on my new email (listed at the bottom
of the readme) about it so I can fix it]
-----------------------------------------------------------------------------


This mod can be added to other sites and mods, provided that you, the site owner, or mod creater contacts me for
permission before you add it, and I am credited as the mod author.

Enjoy.

Josh "Devrith" Creech
Email: Devrith@gmail.com

P.S.- If you ever want to get in contact with me, feel free to email me or add me to MSN. My email is listed above.