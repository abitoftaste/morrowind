*****************************************************************

     The Elder Scrolls III
           MORROWIND:
 
     Telvanni Robe Version 2

	  By MP*Canus
		
*****************************************************************

Index:
1. Installation
2. About
3. Playing the Plugin
4. Save Games
5. Credits
6. Contact
7. Usage

*****************************************************************

1. INSTALLING THE PLUGIN

To install the plugin, simply unzip into the root Morrowind 
directory (e.g. C:\Program Files\Bethesda Softworks\Morrowind), 
keeping pathnames intact. 

*****************************************************************

2. ABOUT

This is an update to the original Telvanni Robe, with unique file
names to avoid conflicts, and DDS textures replacing the old BMPs.

*****************************************************************

3. PLAYING THE PLUGIN

From the Morrowind Launcher, select Data Files and check the box 
next to Clean Telvanni_Robe_V2.esp

*****************************************************************

4. Save Games

This plugin should not (*should* not. Hopefully not. ;-)) invalidate 
your old saved games. If you save your game while this plugin is 
loaded, you may encounter error messages when you reload the saved 
game without the plugin. But you should be able to continue on with 
the original game.

*****************************************************************

5. Credits

Bethesda, of course. Bask in their glow, mortal! Original meshes 
and textures are theirs, and my edits are mine.

*****************************************************************

6. Contact

I used to be worried about sharing my email due to spammers, but
lost that fear as I got more and more and more spam. 

So feel free to email me at canus@cox.net with questions 
or comments. But *** please *** make the topic clear- I have a 
habit of deleting garbage emails without reading them, and I 
have it set to permanently delete emails in the deleted folder 
on exit.

*****************************************************************
     
7. Usage

Feel free to use this in any mod, but lemme know so I can impress 
my cats. ;-)

*****************************************************************