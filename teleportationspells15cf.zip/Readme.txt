*-*-* Teleportation Spells *-*-*
================================
-*-*-      Version 1.0     -*-*-

-^-^- By Josh (theboyudreamof99)
-^-^- kenshin10k@yahoo.com

================================

To install this mod, simply...

1) Extract Teleportation Spells.zip to your Morrowind/Data Files directory

2) Load the Morrowind startup menu

3) Click Data Files

4) Double-click Teleportation Spells.esp

5) Click OK

6) Click Play

================================

What this mod does...

* Adds teleportation spells to every village/town/city of considerable size (by considerable, I mean at leat one shack and an NPC 8D )

* 22 spells in all...locations are as follows...

-Ald-ruhn
-Balmora
-Caldera
-Dagon Fel
-Ebonheart
-Ghostgate
-Gnaar Mok
-Gnisis
-Hla Oad
-Khuul
-Maar Gan
-Molag Mar
-Pelagiad
-Sadrith Mora
-Seyda Neen
-Suran
-Tel Aruhn
-Tel Branora
-Tel Mora
-Tel Vos
-Vivec
-Vos

* Spells can be bought at the Ald-ruhn Guild of Mages from Delas Mrania

================================

Bugs -

None known.

If you find a bug or a town that I missed, email me at kenshin10k@yahoo.com

================================

Enjoy