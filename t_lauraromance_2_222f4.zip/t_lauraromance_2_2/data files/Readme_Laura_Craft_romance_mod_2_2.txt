- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
PLEASE READ THIS README-FILE BEFORE INSTALLING THE MOD!!!
IMPORTANT INFORMATION, ESPECIALLY FOR THOSE WHO ARE USING VER. 1.0-2.0 OF THIS MOD!!!
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


Laura Craft Romance and Adventure mod ver 2.2 - TRIBUNAL required

-------------------------------------------------------------------------------------------------------------------------

The current version of this mod may be found at: http//emma.tesmods.net and http://rethan-manor.net/phpBB2/index.php?c=9 

If you have received this mod from any other source it may not be the latest version!!
 
-------------------------------------------------------------------------------------------------------------------------



Story: Emma 
CompanionScripts: The other Felix
Contact: e-mail: emma9158@hotmail.com forum: http://rethan-manor.net/phpBB2/index.php?c=9 


PLEASE NOTE: This girl's name is Laura Craft, NOT Lara Croft, and she has NO connection to Tomb Raider!!!

1. Intro 
2. What is new?
3a. History ver 1.0-1.2.1
3b. History ver 2.0
4. Compatibility
5a. Installation - VERY IMPORTANT!!!!! PLEASE READ!!!!
5b. Upgrading - VERY IMPORTANT!!!! PLEASE READ!!!!
6. Changing heads
7. Adding teleport destinations
8. Trouble shooting
9. Credits
10. Further uploading

---------------------

1 - INTRO

---------------------

Do you want some romance in your Morrowind life? Can you stand the thought of a Morrowind girlfriend who sometimes acts and talks like a real life girl? A girl who will get mad at you if you try to bribe her, but will enjoy a pleasant gift or sharing a bottle of Mazte at a nice tavern? A companion who also has her own problems - and an important mission to take care of?
  If the answer is yes, this mod might be what you are looking for. It adds a story-line and 17 quests, some of them very simple "lover's quests", some of them very rewarding, while others might be dangerous and time consuming. As time passes, you will be able to develope your relationship with Laura, for better or for worse. 
If you keep on playing as usual, the quests will probably not interfere very much with your ordinary gameplay. Laura will basically respond like other companions, but now and then, when you least expect it, she will bring up new subjects and new missions. This will only happen at certain places and during certain conditions, so there might be hours of gameplaying between each quest.
  Like in the (very) old Girlfriend Breton plugin, Laura Craft will still be your old time girlfriend, and you will find her outside her little cottage, just to the left of the bridge to Vivec Foreign Quarters. However, she will have a very much extended background story to tell you, and, unless your personality is very high, she will be reluctant concerning her feelings towards you. You will probably need to do some dating or maybe fulfil some of her quests in order to convince her that you are "worthy" her devotion. 


------------------------------

2 - WHAT'S NEW IN VER 2.1-2.2?

------------------------------

The story-line is the same as in ver 1.0-2.1. I am hoping to soon continue the story-line, but there are other modding projects I need to complete first.

Ver2.2:

added new animations by RX31. Laura can now "kiss", she can go to sleep, and she has adapted a new dancing style. If you have played The Underground by Qarl, you are already familiar with the new animations, as they are also used there. The scripting of kiss- and go-to-sleep-animations is based on Qarl's ideas but reworked for Laura by The Other Felix.
A sound file has also been replaced. Apart from this, only minor updates.


Ver2:1
Here, many things have been very much changed, mostly thanks to The Other Felix' scripting efforts:

a) FOUR LOOKS - this mod includes four esp-files with four different heads and hair-styles for Laura. The "old" one is how she has always looked - with head and hair by Rhedd. The "new" heads have I made especially for Laura, two of the "new" hairs are from Gorg's Beauty Pack, while the third is a recolor of one of Rhedd's hairs. (Screenshots are enclosed). Move the esp with your favorite face from its subfolder to the Morrowind data files section!

b) EXTENSIVE RECALL-FUNCTION. Travelling with Laura is now extremely easy, as you can at any time recall her to any exterior location, and several interiors (in Mournhhold) as well. If you are standing on a small island in the Sheogorad archipelag and suddenly want Laura's company, just contact her telepathically, and she will turn up right beside you. If you are already travelling together with her, she will follow you to your "Mark" whenever you cast recall - she does NOT have to cast a "Mark" in order to do so. (PLEASE NOTE: The recall options will ONLY be available once you have completed the first three of her quests, and received the "Lover's Teleportring" as a gift from her. If you have upgraded from a previous version and already have the ring, it should immediately start functioning for recall casting - just make sure that Laura has a recall item, like an amulet or a scroll.) 
 On top of the recall function, Laura will, as in previous versions, follow you when you cast intervention spells and when you travel to propylon chambers. You will also be able to decide on several "meeting points" with her, as well as use the "Lover's teleport ring" to teleport the two of you to 18 different pre-made locations. 
 You must just be aware of one thing - Laura is a warrior, not a mage. Her magic skills are initially not that good. Therefore, you must make sure that she has intervention/recall amulets/scrolls/rings - or you must train her in mysticism.

c) SEAMLESS ATTRIBUTE LEVELLING. Up to now, it has been possible to level Laura's skills, but her attributes have been fixed. From this version, Laura's attributes will be levelled to match those of your PC-Character. But, she will always be a warrior, not a clone of your PC-Character. Which means that if you play as a level 14 mage, her strength, personality, intelligence, magicka, health etc will not be the same as yours, but the same as other npc-warriors at level 14. 

d) FURTHER DEVELOPED SKILLS LEVELLING SYSTEM - NOW WITH LEVELLED SPELLS. Thanks to The other Felix, Laura is since ver 2.0 the first companion that will raise her skills in the same way as the player - BY PRACTICING HER SKILLS! Give her a longblade and a medium armor, and she will improve these skills each time she participates in combat. Give her a light armor and tell her to use her spells, and she will improve her spell casting and light armor skills. And so on. Her mysticism skills will improve each time she successfully cast an intervention spell.
This feature was there already in ver 2.0. But, from ver 2.1, Laura will also level her restoration skill when healing herself, and as her restoration skill improves, she will be able to heal you and cure you from various diseases.
All of her spells are now levelled - as her spellcasting abilities get better, she will learn new, more powerful spells and start to use them. 
As for her combat and armor skills, you can also develope them in a friendly combat between the two of you.
As a complement to the level-by-practicing-system you can also develope her skills by BUYING STUDY BOOKS, just like in the previous versions. If you add Laura to your game, her initial MAJOR skills will BE SET TO A LEVEL THAT MATCHES THE PLAYER's. If you are upgrading from ver 1.0-2.0, Laura will keep the skills she already had in your ongoing game. (Just make sure that your PCCharacter is in the same cell as her when upgrading, else this won't work!)
You can keep track of Laura's current skills by checking her dialog topic "my skills".
A back-up script is keeping track of her skills, so that she will keep them even if you happen to run into the Bethesda original 72 hours bug (which causes npc's to "reset" if you are separated from them for more than 72 gamehours)

e) AUTOMATIC LEVITATION/WATERWALKING AS AN OPTION. As many other companion mods use automatic levitation/waterwalking (companion will levitate/waterwalk whenever you do so), this feature has also been added to Laura. However, in order to keep some of her more "advanced" combat options (such as having her attacking with bow from the air while you do the melee combat), the automatic levitation/waterwalking is OPTIONAL - you and Laura decide in dialog if she should use this feature or not.

f) HEALING AND RESTORING MAGICKA. If you gain something, it costs something... Up to now, Laura has been able to restore her health and her magicka without you having to do anything. But, from now on things have changed. Laura will still cast all spells that are related to companion following abilities for free (such as levitating, slowfalling, waterwalking), but other spells - including healing spells - will cost her magicka points. It's up to you to give her magicka potions, or to let her rest now and then in order to restore health and magicka. As for healing, she can either heal herself by healingspells, or you can give her healing potions. Please note that the game engine will only make her drink healing potions during a battle, when wounded, but you can make her consume healing- and magicka potions also by using dialog.

g) EXTENDED INTERACTION with npcs from other mods. Already in the previous version, all other npcs were aware of Laura if she was in following mode and would comment on her. In this version, some of the npcs from my other mods will also interact in other ways. For instance, both Janicia from Lost Heir and Witchgirl Morgana will be able to heal Laura (although Morgana would of course prefere to dump her at first possible daedric ruin :-p). I have also taken steps to make sure that Laura will be able to interact further with my other npcs once I update the other mods or upload new mods. So, be sure that once there are toddlers and teenagers in Morrowind, Laura will know about it. And if you start flirting with other npc ladies by me, be aware that she just might discover what you are up to. (Please note: interaction between mods is still an area that hasn't been used very much, and as long as Laura is the only mod prepared for such interaction, the options are still limited. But, it's a start that can lead to further enhancements in the long run. So, don't get too disappointed if the interaction at this point isn't what you would have wanted it to be). 

--------------------------

3a - History ver 1.0-1.2.1

--------------------------

NEW features:
- Laura literally talks to you when in dialog mode
- Laura will dance for you or sing a song if you ask her to do so.
- Laura will have her own way of dealing with you if you try to bribe her. And she will not be pleased if you try to use her ebony armor for your own protection.
- Just like a "real life" girlfriend, Laura will enjoy a nice gift or sharing a drink with you at a pleasant tavern.
- Laura will "know" if you have a weapon pointing at her, and this will influence the dialog.
- Laura will have her personal replies to nudity. 
- Laura will be able to communicate with you by telepathy.
- Laura will tell you about her current skills (i.e. you won't have to keep track on which of her skills you have been developing).
- One of Laura's "rewards" will make travelling together with her much easier.
- A little surprise is waiting for you in her basement. 
- New combat options: You can a) order Laura to teleport back home if she gets severely injured b) order Laura to stay out of fight, until either she or you get severely injured 
- after really gaining Laura's affection (by solving a couple of her quests) she will show you her Really Very Special Dance and she will.... oh, no, you'll have to find that out for yourself.
- A backup-variable setting keeps track of how Laura's skills have been developed, as a guarantee that she will not lose any skill improvements if you get long-term separated. 
- The step-aside-function, introduced in the NPC-move mod by Noviere (availabe at Summit), has been added. A very handy function whenever Laura is blocking your way
- Laura can now be ordered to stay at one spot and COVER you during the fight. 
- The infamous Bethesda-bug that causes companion to take damage if passing through a door with slowfall active has been resolved. Same goes for the bug that causes companion to disappear if levitation is active when passing through a door. 
- Laura's swimming abilities have been improved - she is now as good at swimming as at levitating.
- Laura will now automatically report if she is injured and needs healing.

---------------------

3b - History ver 2.0

---------------------


a) THREE LOOKS - this mod includes three esp-files with three different heads and hair-styles for Laura. The "old" one is how she has always looked - with head and hair by Rhedd. The "new" heads have I created for Laura myself, and the "new" hairs are from Gorg's Beauty Pack. (Screenshots are enclosed). Move the esp with your favorite face from its subfolder to the Morrowind data files section!

b) A BRAND-NEW LEVELLING SYSTEM. Thanks to The other Felix, Laura is the first companion that will raise her skills in the same way as the player - BY PRACTICING HER SKILLS! Give her a longblade and a medium armor, and she will improve these skills each time she participates in combat. Give her a light armor and tell her to use her spells, and she will improve her spell casting and light armor skills. Her mysticism skills will improve each time she successfully cast an intervention spell.
As a complement you can also develope her skills by BUYING STUDY BOOKS, just like in the previous versions. If you add Laura to your game, her initial MAJOR skills will BE SET TO A LEVEL THAT MATCHES THE PLAYER's. If you are upgrading from ver 1.0-1.2.1, Laura will keep the skills she already had in your ongoing game. (Just make sure that your PCCharacter is in the same cell as her when upgrading, else this won't work!)
You can keep track of Laura's current skills by checking her dialog topic "my skills".
A back-up script is keeping track of her skills, so that she will keep them even if you happen to run into the Bethesda original 72 hours bug (which causes npc's to "reset" if you are separated from them for more than 72 gamehours)

c) PRACTICE TOGETHER. Laura will be delighted to practice her fighting skills together with you. You will not have to worry - she will end the combat before any of you get severely injured (and, as she is a girlfriend and not an ordinary standard companion, you might be able to guess who she preferes to be the "winner" of your combat sessions...) Please note: if you are using other companion mods together with this, make sure that the other companions aren't in following mode when you and Laura are practicing together; if she hits you, they will get VERY upset, and probably kill her...

d) EXTENDED COMBAT OPTIONS. Choose among the following: a) fight together b) fight together without spellcasting c) fight together - melee weapon only d) marksman only e) guard/distance bowman with cover-function (marksman/spellcasting/or melee) f) stay out of fight g) flee if severely injured.

e) SMARTER MARKSMAN AI - will automatically switch to melee-weapon if engaged in close combat (note: if you are using Giants or Blood&Gore, please read compatibility section below)

f) INTERVENTION AND PROPYLON CHAMBERS - Laura can follow you when you cast intervention spells and when you travel to the propylon chambers. (Until she has practiced her mysticism skills, she'll need an intervention item to cast intervention spells). As this mod only requires Tribunal, the Fort Frostmoth-destination has been outcommented in her  interventionscript. If you are using Bloodmoon, simply remove the ; in front of the Fort Frostmoth lines, and she will follow you there, as well.

g) ALL NPC'S ARE AWARE OF LAURA - if Laura is in follow-mode, the npc's you meet will "notice" her and comment on her (topic: "a companion - Laura")

h) WILL ACCEPT ANY HOUSE AS HER NEW HOME - once you have completed the quests for Laura, she will be ever so happy to move in with you in your Morrowind house, and will refer to it as her new home. If you have many houses, she will accept them all as her home (regardless if they are modder-made or belong in the original game). 

i) "SHOPPING-OPTION". If you want to be on your own for a while, you can send Laura to Vivec to "do some shopping".If you give her money to spend, she will be as happy as a songbird, and might even buy a little gift for you (if you are REALLY lucky, it's even something useful and not only a new common shirt - there are + 20 different outcomes of this).

j) "FLATTER-OPTION". As you probably know, bribing her is pointless and expensive. Instead of buying her gifts or drinks, you can now also "flatter" her. The result is however random and you can never be sure how she will react.

k) NEW OUTFIT - in a new chest close to the bookshelf, you will find Laura's Goldleopard domina dress, that I have made especially for her. (Please note: if you are using Better bodies-mod, you will have some clipping issues, especially with the gloves.)

l) TELEPATHY RING HAS NEW OPTIONS. A few new "meeting points" have been added to the telepathy ring.

m) IN-BUILT FIX FOR THE 72 HOURS BUG - but the player has to contact her every day (using the telepathy ring) in order to avoid the 72 hours bug. (It would have been possible to totally remove the 72 hours bug by scripting, but sometimes this bug can be very useful. For instance if the player has first ordered Laura to cast a teleport spell and then teleported himself before she has actually left. This causes her to "go epileptic", and if you haven't got a recently saved game, an alternative is to leave her behind for + 72 gamehours, which will make her act normal again).

n) EXTRA SPEED - you can choose between "normal" and "hurry up", which will make her run faster (but it will also make her look redicilous if used together with other companions)

o) JUMPS OUT OF THE COMPUTER AND MAKES COFFEE... - (WOOPS! not in this version... maybe in ver 3.0?? ;-) ) 




-------------------------

4 - COMPATIBILITY

-------------------------

Laura is using a script that should work very well together with other companion mods. 


PLEASE NOTE: 
- Laura Craft is NOT compatible with and was never meant to be compatible with plug-in Boyfriend Indiana James.
- If you are using Giants and/or Blood&Gore, and these mods are "newer" than this mod (i.e. listed below Laura Craft Romance and Adventure in the Data Files section where you choose plugins for your gameplay), some minor functions in this mod won't work as supposed. Laura will not automatically switch from marksman to melee weapon when in close combat, and each time she uses intervention, she will scream "Attack!" once as she reaches the temple. To fix this, just open this mod in TESCS and save it without doing any changes. This will make this mod "newer" than the other ones (as Laura's voice entries are filtered for her ID-name, she won't cause any conflicts in Giants or Blood&Gore).
(PLEASE NOTE: if you are already using this mod in your game and open and saves it in TESCS, this could cause doubling issues in your saved game. Make sure that the bedroom door in Laura's house is closed before opening the mod in TESCS, else it will definitely be doubled.)

The dialog-writing structure is intended to be made in a way that should avoid overwriting by other plugins. If another, newer, plugin should have similar topic/s (which usually causes the topic to disappear in the older plugin), the topic should still be available, although not highlighted. In order never to get the "key-topic" "together" overwritten, I have choosen to spell it "t0gether", which I hope you will not find too irritating.



-------------------------------

5a - INSTALLATION IMPORTANT!!! PLEASE READ!!!

-------------------------------

ALWAYS MAKE A SAFETY COPY OF YOUR SAVED GAME BEFORE ADDING OR UPGRADING ANY MOD, THIS ONE INCLUDED!!!!

FOR THOSE OF YOU WHO AREN'T USING ANY VERSION OF MY MOD:
Just UnZip to your Morrowind-library. There are three esp-files to choose among, one for each optional face. Pick your choice and move this esp from its subfolder to the Morrowind Datafiles section.

An alternate way to proceed, which I personally prefere, is this:
Create a subfolder on your desktop.
Unzip the mod to the sub-folder. Doubleclick on the sub-folder.
Inside, you will find one meshes folder, one textures folder and four different folders with the four different esp-files for Lauras four looks.
Take the meshes folder and DROP it into your Morrowind datafiles directory. It will automatically MERGE with your existing meshes folder (which will guarantee that all meshes ends up at the exactly correct place). You will get a message concerning this from the computer, say OK. 
Now, take the textures folder and DROP it into you Morrowind datafiles directory.
Finally, check the four different esp-files and choose how you want Laura to look. Place the esp-file with your favorite face into your Morrowind datafiles directory.

---------------------------------

5b - UPGRADING  IMPORTANT!!! PLEASE READ!!!

----------------------------------


FOR THOSE OF YOU WHO ARE USING VER 1.0-2.0 OF LAURA CRAFT ROMANCE AND ADVENTURE MOD:
If you want Laura to keep her previous skills, there are two things you should do before upgrading: 1) make sure that your PCCharacter is in the same cell as Laura when upgrading!! 2) Before upgrading, buy her a study book in any skill (this will update her skill-update script).
In order to make ver 2.1 work properly, you will have to CLEAN YOUR SAVED GAME. The procedure is very simple and should take you less than five minutes. Do like this (instruction made by Fernelf):
a) MAKE A SAFETY COPY OF YOUR SAVED GAME!!! 
b) Place the copy of your savedgame in the Morrowind data files folder. Rename your saved game from an ess-file to an esp-file (right-click on the save and hit rename.Exchange the letters ".ess" with ".esp", hit enter). 
c) open up TES Construction set, highlight your renamed esp-file and mark it with "X". Hit the "details"-button (don't load the esp, just hit details). 
d) In the details-list, look for and highlight a line called �NPC�+the ID-name of your npc, for instance "NPC-11AA_Laura". DELETE this line. Use the "delete"-tab. You will get a question if you really want to delete the line, say OK to this. If you look in the details list, you will now see a "|" in front of the NPC-11AA_Laura-line. This means that you have successfully deleted the line. Please note: there is also a line called "NPCC-11AA_Laura". DON'T touch this line. 
e) Close the TES Construction set (do not save or load the esp-file, just close TES construction set) 
f) Go back to your data files folder and find the saved game esp. Right click and hit rename. Exchange the letters ".esp" with ".ess". 
g) place your updated ess-file among your saved games. Now, you are ready to play. 
Please note: this is rare, but some people may have to do one extra step, as they have problems to revert their new esp back to an ess. This is how to fix it:
go to �start�
hit my computer
hit tools
hit view and uncheck the last line "hide file extensions"
hit apply
now go back and now right click on the esp and hit rename and place the s where your p was. 
PLEASE NOTE:
- When you return to your saved game, you will most likely get a couple of error messages. These shouldn't be harmful, as they are basically only telling you that some of the scripts look different and that Laura isn't placed in the same cell as she is in the construction set.
- When you return to your saved game, Laura will probably NOT have the sharing option. In order to regain it, do like this:
a) Choose topic "t0gether", ask her to wait for you where you are. Close the dialog window.
b) Re-open dialog window. Choose topice "t0gether" and ask her to follow you. Voila! The companion sharing will return. (Should you at any occasion "lose" the sharing option, just do the same thing as I have just described).
- At one time when I upgraded and altered Laura's looks, she had disappeared when I reloaded my saved game. As I had her telepathy ring available, this didn't cause any problem - I just told her to meet me in Balmora, and when I went there, she met up, with her new looks and with everything safe in her inventory. So, never forget that you can use both the telepathy ring and the little Vivec teleport ring to get Laura back, should you somehow lose track of her. 

 


----------------------------

6 - CHANGING HEAD/RACE/ETC

----------------------------

With this mod, I have added four different esps with four different looks for Laura. You can switch esp whenever you want to, but you will have to CLEAN YOUR SAVED GAME in order to make the changes show up. (See description in the INSTALLATION - UPGRADING section of this readme.

If you want Laura to use another head from any other headpack that is easy to fix. Just got to the construction set, check the boxes for this mod, for the headpack mod and of course for Morrowind and Tribunal. Make sure that Laura is the "active" mod.
Open up the mod in the constrution set. To the left, you will see a couple of tabs. One of them is called "npc". Click here. At the very top of the list, you should find 11AA_Laura (I generally use the prefix 11A or 11AA). Double-click on the line with her ID-name. That will bring up the NPC-infobox. Here, you can change her race, her looks and even her name (just DO NOT change her ID-name). To the very right, you will find a list of heads and hairs. Just pick your choice and hit the OK button. Her race is listed below her name, you can change her into anything you want. But, her voice will remain the same, as it is programmed in the dialog.
If you go to the Vivec-cell where she is (list of cells below the render window, there's a * at the Vivec cell where she is), you can see her change her appearance each time you click "OK" on her npc-info-box.
Once she looks as you want her to look, just save the mod. 
Please note: If you are changing her race, you will have to add the animation file again, else she will not dance/kiss/sleep. The animation-button is right below where you change head and hair, and the new animation is called anim_Synda4.nif
One thing, though: If you are already using Laura in your game, you will probably (but not always) have to clean your saved game in order to make the changes show up ingame (see instructions above). This should only take you a couple of minutes.


---------------------------------

7 - ADDING TELEPORT DESTINATIONS

---------------------------------

Laura can recall to any exterior location, and to a couple of pre-determined interior locations as well (in Mournhold). But, if you are familiar with the construction set, it is possible for you to add recall to further interior locations
Just open up the mod in TESCS, and hit the "pen"-icon in order to check out the scripts. The script you are looking for is called 11AA_Lauraintervention. 
If you scroll down to line 168/169 you will find an outcommented recall-option - Laura's cottage. This one can be added if you remove the ;. Or, if you would rather like her to be able to recall to another interior location, you can simply replace the words "Laura's house" with the name of any other interior cell you'd rather want her to be able to recall to. 


----------------------------

8 - TROUBLE SHOOTING:

----------------------------

INSTALLATION:

1) LAURA HAS AN EXCLAMATION-MARK INSTEAD OF A HEAD: This is a rather common problem. When you unzipped the files, they ended up
inside a folder in your data files section, right? (This happens all the
time, as far as I know it's because you use an US/british version of Windows
while I use a scandinavian). And then you tried to drag each texture and
meshes manually into their right folders?
What you should do is either of these suggestions:

suggestion a) Move the new folder you got when unzipping to the desktop. Double-click on
it. You'll find one esp-file, one meshes folder and one textures folder
inside. DROP the meshes folder into your data files section. It should now
automatically merge with the existing meshes folder (probably you will be
asked a question about existing files, say yes to this). DROP the textures
folder into the data files section. It should also merge with the existing
textures folder. Choose which esp-file you want to use (i.e. which head and hair you prefere) Move the esp-file to the data-files section. You're ready
to go, and now everything should work just fine.

suggestion b) Create a subfolder on your desktop.
Unzip the mod to the sub-folder. Doubleclick on the sub-folder.
Inside, you will find one meshes folder, one textures folder and four different folders with the four different esp-files for Lauras four looks.
Take the meshes folder and DROP it into your Morrowind datafiles directory. It will automatically MERGE with your existing meshes folder (which will guarantee that all meshes ends up at the exactly correct place). You will get a message concerning this from the computer, say OK. 
Now, take the textures folder and DROP it into you Morrowind datafiles directory.
Finally, check the four different esp-files and choose how you want Laura to look. Place the esp-file with your favorite face into your Morrowind datafiles directory.

2) You get an error message concerning script mskills2. This will most likely happen when you are upgrading, and should be harmless. If your PCCharacter is in another cell than Laura when upgrading, the result might be that Laura will not keep her "old" skills - instead her major skills will be set to match your PCCharacter's. If you want her to keep her "old" skills, make sure that she is together with your PCCharacter when upgrading, and also make sure to buy her a study book right before upgrading (which will update her skills-script).

3) After upgrading, there are two doors to Laura's bedroom. No worries, this often happens when upgrading a mod. Just open up the console (usually behind the � or ' key, depending on keyboard), click on the extra door so that it's IDname shows up at the top of the console. Type: disable.
The extra door will be gone for good.

4) After upgrading the mod to ver 2.1, there is no significant difference in Laura's behaviour, no new topics, no new face, nothing. Answer: You must clean your saved game first (see above), else Laura will be the same as before.

GAME PLAYING:

1) When flying over the ocean together with Laura, you will of course sometimes be attacked by cliff racers. She will fight them, but after the fight she might be standing in the air, waving her sword, refusing to following you. This is caused by the angry slaughter fishes in the water below her; she wants to fight them, but can't determine their positions. You can either go down and start fighting them, yourself, and she will follow you. Or you can use the telepathy ring, to make her stop fighting and instead follow you.

2) If something should happen with the "companion sharing" option, you can always get it back by telling Laura that you want to be alone for a while. When you ask her to join you again, companion sharing will automatically be added. 

3) If you ask Laura to teleport and then start to teleport yourself before she has actually left, this will cause an error in her behaviour. When you meet her again at the new location, she will be "shivering" and "spastic" and she will not follow you. This is because she cannot "feel" her x y z-coordinates, and the problem is more likely if you are using several companions together. You will either have to reload your previous saved game, or take advantage of the 72-game-hours bug: leave Laura and stay away from her for at least 72 gamehours, without contacting her with the telepathy ring. Then return back to her, and she will behave normal again (please note: after the 72 hours, the telepathy ring won't work until you have met her again). According to some reports, you can also reset her by hitting her a couple of times, but I cannot guarantee that this really works, so please save your game before you try this solution.

4) PLEASE NOTE: If you are separated from any companion for more than 72 game hours, the companion's skills will generally be reset back to initial value. This shouldn't happen with Laura, as she has got a backup-script that stores her current skills. 

5) This mod also includes a "fix" for the 72hours-bug - by sending her to her cottage or to Vivec Foreign Quarter Plaza and then contact her with the telepathy ring once every day, you can totally avoid the bug. If the 72-hours-bug executes, the telepathy ring will temporary stop working. As soon as you meet Laura again, it will start to work as it should. As a double back-up you have got Laura's Vivec Teleport ring, that will teleport her to Foreign Quarter Plaza. This ring will never be affected by the 72-hours-bug, so you will never "lose" her.

6) Laura can only use recall to outdoor locations, (and to a few specific pre-determined interior locations, for instance in Mournhold). If you ask her to cast recall to an interior location, you will simply get a message that she is unable to do so.
Her new recallsystem generally works very well, but there is one situation where you will run into problems: if you tell Laura to teleport away from you (for instance to Vivec) and then ask her to join you again, while you are still in the cell where she left you, she will be partly "buried" in the ground when she arrives. If this should happen, simply leave her, go to another cell, use the telepathy ring and decide another meeting point with her. She will show up there, and everything will be fine.
In order to be sure that Laura is able to follow you when you cast recall or intervention spells, you must give her recall- and intervention items, like rings, amulets or scrolls. As he mysticism skill increases, she will more and more often be able to cast the intervention and recall spells without any items. But, you must always have the Lover's teleport ring in your inventory in order to make her use recall.

7) If you add new mods to your ongoing game, you might get an errormessage saying something like "error script 11AA_mskills2 - unable to locate reference for 11AA_mskills2 script". Don't worry! This error message is harmless and only indicates that Laura has been moved from the location where you originally found her (outside her cottage). The 11AA_mskills2 script will recognize her and start running as soon as the game has started and you and Laura are in the same cell. 


-------------------------------------------------------------------------

9 - CREDITS

--------------------------------------------------------------------------

First of all, I want to give my VERY SPECIAL THANKS to The other Felix, who has continuously added so much of his knowledge and creativity to this mod. He has developed the whole new level-by-practice-system, he has added the brandnew recall system as well as the intervention/prophylon chamber utility, he has further enhanced the companion script, created the telepathy ring, taught me how to use the voice section and helped me to sort out and clean up all mistakes in my own half-working scripting efforts. Without his suggestions, his work and his constant support, this ver. 2.1 would never had become reality. Although I have created the girl Laura, her story and her personality, it is The other Felix who has given her the "brain" she has today.

I also want to give my VERY SPECIAL THANKS to GRUMPY, the developer of the original warping movement script. Without his groundbreaking work, neither Laura nor any other companion would have been a pleasant company in Morrowind. On top of that, he is also a great modder friend, with whome have been constantly debating, arguing and laughing for more than two years. Without his friendship, support and feedback, modding wouldn't have been half as fun as it is today.

Many, many thanks also to PETER, who has spent time on making various fixes for Laura (all of them can be downloaded from my site), and for many valuable suggestions regarding both Laura and my other mods.
 
Laura's "old" head and hair is made by Rhedd(Rhedd's readme file is enclosed). 
Two of Laura's "new" hairs are made by Gorg, the third is a re-color of one of Rhedd's heads. (the heads are made by me, meshes by Rhedd).

The new animations, added in ver 2.2, is made by RX31, and the scripting for them is based on Qarl's ideas but reworked for Laura by The Other Felix.. Many thanks to both RX31 and Qarl for letting other modders use your work!

The npc-movement in the companion-script is based on an idea from Reznod that has been developed by Grumpy, who has kindly offered me to use it in my plugins. Some additional enhancements, suggested by Devlor, has also been added. Finally, The other Felix has made some extraordinary enhancements concerning particularly the levitating, swimming and levitating/fighting parts of the movement script.
The skills-report-script is basically the same as TheLys has used in the "Give Your Orders"-mod.
The "Lover's ring" script is based on and reworked from the 18 destinations teleport ring script made by Scott Fischer.
The step-aside-function was introduced in the NPC-movement mod by Noviere, available at Summit.


I would also like to add my special thanks also to GarryB and Robeast1965 (who has both helped me to correct the lousy english grammar), Edwardsmd, Knownalien,tmartin827, Edwardsmd,  Beardo, Devlor, Dinkum Thinkum, Fernelf, Sunsi, Zor_Valachan, Adamus, Ian, Llorac, Straydog and Squelchy Underfoot for giving me help, support and numerous of valuable suggestions. Laura has now existed in the Morrowind world for more than two and a half years, since the initial Girlfriend Breton ver 1.0 was released in september 2002. I might have forgotten to mention names of players or modders that have offered valuable suggestions during this time. If so, please forgive me, as I haven't had any intention to leave anyone out.


------------------------------------------------------------------

10 - FURTHER UPLOADING

------------------------------------------------------------------

The main home of this mod is on my site, http://emma.tesmods.net and my forums, http://rethan-manor.net/phpBB2/index.php?c=9

Should something happen so that the mod is no longer available on the net, I do want you to try and contact me. In case you have been unable to reach me for more than one month, please feel free to upload this mod IN ITS CURRENT STATE to one of the public Morrowind download sites. Please send me an e-mail or PM to notify on this! 

Please do not upload any altered versions of this mod anywhere without my knowledge and agreement!

- Emma



-----------------------------------------------------------

e-mail: emma9158@hotmail.com 
home-site: http://emma.tesmods.net
forum with hints- and spoilers- section: http://rethan-manor.net/phpBB2/index.php?c=9 
-----------------------------------------------------------

   
