Dock in Tel Fyr

Adds a shipmaster to the empty dock in Tel Fyr. She can take you to Tel Mora, Tel Aruhn, Sadrith Mora and Tel Branora. She also has a small quest, but that is optional. 

Cleaned with TESAME.