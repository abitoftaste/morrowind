==============================================
Telperion Basement Addon
By Calislahn
==============================================

INDEX:

-> Requirements
-> About this mod
-> Installation
-> Known Bugs & Issues
-> Incompatibilities & Save game warnings
-> Credits & Usage
-> Contact

==============================================
REQUIREMENTS:
==============================================
This Mod requires Bloodmoon, Tribunal and Telperion V1.3.

==============================================
ABOUT THIS MOD:
==============================================
This adds a basement area to the treehouse, the door can be found under the staircase in the lower level kitchen area.

Originally I made the house with my Dryad Mystic character in mind but have recently moved my rogue in who has a large collection of armour and other assorted spoils of adventure. While there is plenty of shelving and storage within the house itself I wanted somewhere to display my armour, I could have just placed some mannequins within the house from my mannequin mod but I am one of those unfortunates with terminal fps trouble, I didn't think my computer would like all those npcs standing about what with all the other things in the house as well, so I built myself this basement instead. And as I know there are other pack rats about I decided to release it.

In the basement you will find:

6 Male Better Bodies Mannequins
6 Female Better Bodies Mannequins
17 chests with 1000 encumberance each
6 large tables
6 enclosed bookcases
2 open bookcases (one of which has 9 of the chests on)


===============================================
INSTALLATION:
===============================================
Just extract to your Morrowind directory.

===============================================
KNOWN ISSUES OR BUGS:
===============================================
If you are already using the house this should not invalidate your savegame but I would recommend you save outside of the house and its containing cell before adding it just to be safe.


===============================================
INCOMPATIBILITIES & SAVED GAME WARNINGS:
===============================================
Always make sure that you backup your existing savegame before use.

There are no known incompatabilities with this mod.

This mod was cleaned with the Enchanted Editor.

===============================================
CREDITS & USAGE:
===============================================

KWShipman - rich table and bookshelf.
 

Please do not upload to your own site without asking me first, I like to keep a track of where my mods are hosted :)

=============================================
CONTACT
=============================================
EMAIL: calislahn@lycosmax.co.uk
WEBSITE: http://www.calislahnsmods.co.uk/index.htm