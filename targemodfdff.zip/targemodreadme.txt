Targes v1.2 - Brian Hodge


--v1.2: Fixed Eagle Targe Foot/Shield Slot Problem
	The buckler is now smaller than the targes
--v1.1: Fixed Texture Alpha Problem

Problems (to be fixed):
-Clipping problem while walking with all shields
-Buckler model bug--just a little misalignment caused by 3DS Max.

New in this mod:
Imperial Targe

This mod adds five new modelled shields to Vvarendell. They aren't extraordinary, they're plain and circular, as targes are. You can find a screenshot at http://www.gameslayer.org, or, if you have downloaded the mod, a screenshot is included.
These shields can be found in a few places around Vvarendell. Look for them at Alusoran's shop in Vivec, Foreign Quarter; Anruin in Sadrith Mora; and Ra'Virr's in Balmora. You'll notice all normal imperial guards have the Eagle targe equipped. I just thought it was stylish. You might see a person here and there that's using one, but they're pretty rare.

Thanks to wherever I got the textures... type in targe on google and you'll find them all. :-P

Just a note: This was my first time using 3D Studio Max to import and export NIF's for Morrowind. These also happen to be my first models EVER made with 3DS Max. Just a reminder if you tend to think my models suck... because they do. I'm in the process of learning. So, in the meantime, enjoy my mods!

Cleaned with TESAME