Telvanni Strongmod version 1.0
Includes:

-Complete interior rebuild of the Telvanni stronghold
-Modified steam centurion guards that attack monsters
-Slight modifications to Uvirith's Grave and the merchants' houses
-Monsters in the dungeon and various hidden treasure
-Teleporter to a few pre-set destinations, and an amulet which takes you to the stronghold at any time.
-Plenty more

A welcome note will be attached to the front door of the stronghold when it is completed, which has further details and information. This mod is relatively polished, but I will probably update it again in the future.

To install:
Copy Telvanni Strongmod.esp to "Data Files" in the Morrowind directory and enable in the game setup.

Contact me at xaltotun@gmail.com with bug reports, feedback, suggestions, etc.
