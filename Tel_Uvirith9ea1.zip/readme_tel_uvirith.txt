The Elder Scrolls III MORROWIND:
Tel Uvirith Stronghold Plugin
Author: Jaysun Huck (Email: anubis@fubarm.com)
		
*****************************************************************

Index:
1. Installation
2. Playing the Plugin

*****************************************************************

     1. INSTALLATION

*****************************************************************

To install the plugin, unzip the files into the Morrowind/Data Files
directory.


*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

From the Morrowind Luancher, select Data Files and check the box 
next to the tel_uvirith.esp file.

This plug-in adds a considerable amount of new objects and containers
to the Telvanni Player Stronghold, Tel Uvirith. Additionally, there are
a few new NPCs that offer services not found previously at the tower.

The first is Arshes Nei, a dark elven Guild Guide that will teleport 
you to Caldera, Balmora, Sadrith Mora and Vivec. To get back to Tel 
Uvirith, you must go to the Guild Guide in Balmora. Additionally, this
lady also enchants items for you and will buy some of the really
expensive items as well as she has a considerable amount of gold on
her.

Nuzzgrond is a Master-of-Arms and is a good trainer for those wizardly
types that need to work on their sword arm.

Finally, down in the dungeon is Mzulecht, the Steam Centurion Armorer.
Mzulecht was re-engineered by Telvanni Enchanters and is not only a 
powerful Guardian for Tel Uvirith, but is also a Blacksmith. Go to him
to have all your weapons and armor repaired.

There are a few other little secrets lying about that I won't spoil for
you here. I would love to get some feedback on this Stronghold. Please
email me with your thoughts. (anubis@fubarm.com)

Thanks and enjoy!