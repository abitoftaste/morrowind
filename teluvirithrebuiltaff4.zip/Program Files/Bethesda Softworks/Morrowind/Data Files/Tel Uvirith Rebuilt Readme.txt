*****************************************************************

The Elder Scrolls III
MORROWIND:
Tel Uvirith Rebuilt
By. Zurin Arctus

*****************************************************************
Please send comments and bug reports to: Zurin_Arctus@juno.com

Index:

1. Description
2. Compatibility
3. Installation 
4. Notes
5. Version
6. Credits


*****************************************************************

     1. PLUGIN DESCRIPTION

*****************************************************************
VERSION:       1.0
PLUGIN TYPE:   Town
BASE FILES:    Morrowind.esm + Tribunal.esm (Version 1.4.Godknowswhat)
PLAYER LEVEL:  1+

(Note this mod is tailored to my Character, who is the Patriarch of the Temple, as well as Archmagister, so you may not like the little back ground story, if you play a hard line Telvanni. There isn't an Imperial presence, though)

The outside of Tel Uvirith is no longer a wasteland, it is now green, and has pleasant weather. The reason for this is an alliance sworn between Master Uvirith and Master Aryon. Also, a new village in the Indoril (Mournhold) style complete with an Indoril embassy has cropped up; all because of Master Uvirith's newly signed alliance with Great House Indoril in return for funding, lots of it.

Features:

- A Total Rebuild of the exterior cells around Tel Uvirith.
- Green landscaping, mild weather (no ash storms) and a small Indoril style village (let it be known now that I, a hum, stole the interiors of most of the new buildings from Nazz's excellent "Gah-Ruhn" mod, part of the excellent Tamriel Rebuilt; also, the cells have renamed and this mod is 100% compatible with his, and all TR mods) using some new models built by Nazz, and Kothloth.
- A new silt strider route running from Malog Mar, to Tel Uvirith, to Vos, and then to Khuul, and Gnisis.
- Sadly, no quests, yet. Maybe in a later update I can add quests to found the town, and some little quests involving conflicts between House Telvanni, and the local Indorils.
- An Indoril embassy using the Tamriel Rebuilt faction model, which has transport to Mournhold.
- A HUGE Library in the Temple, featuring all the books in the Original Morrowind (excluding quest related books, no main quest cheats or anything), and Books from Tamriel Rebuilt's "Books of Tamriel". 
- Tel Uvirith Tower and the original houses that surround the base of the Tower were untouched, insuring compatibly with "Uvirith Inside"
- New Dialogue (should work, but I'm new, so it may be a little weird)

Other plug-ins recommended being run with this plug-in: 
(Optional, just for atmosphere)

Uvirith Inside by. The DopeHatMan
       -Combines �Uvirith Unleashed and �Tel Uvirith Vault�, and adds its own excellent features. This is a GREAT mod, every one should have this.

Face Replacer (and all other Face mods) by various madders       
       -Makes the faces a lot more pretty

MW Visual Pack 2.0 by. Khalazza production, 
       -Replaces standard textures with new, hi-res ones. Very recommended, but the file is quite large, and it may slow down your Frame Rate if you play on an older system.

Rise of House Telvanni by.  Pozzo
       -A nice mod that is the Telvanni equivalent of Pax Hlaalu. It has been released at the time of this writing, but is in BETA version, and is VERY buggy, but the bugs themselves are miner, and easy to correct if you have the time. I also have a "patched� version on my website, but I'd wait for Pozzo's next release.

Havish, by. J.O.G
       -Adds a new land mass with a unique city. Very fun for Thieves. I believe the newest version is even compatible with TR.

Sea of Destiny  by. Clone
        -Adds a large landmass to explore, and is generally very well done. Not compatible with TR and Beyond YsGramor (barely, it still runs, but Dagger Soul has a nice chunk of its land missing)

Tamriel Rebuilt by. Various Modders.
        -A very high quality attempt at rebuilding all of Tamriel. No where near done, but it still rocks.

The Illuminated Order by. Charles J DeVito and LDones
         -Adds a new guild and the ability to become a Lich, very fun.

Beyond YsGramor by. Miles Acraeus
          -Adds a new guild and city. This mod is excellent even if the Odd Fellows are opposed to slavery. :D Incompatible with TR and has conflicts with SOD.
--------------------------------------------------------



*****************************************************************

     2. COMPATIBILITY

*****************************************************************

This Plug-in is clean as to the best of my ability. 
It heavily modifies cells
10, 1 
10, 2 

And slightly modifies
9, 0
9, 1
9, 2
9, 3
10, 0
10, 3
11, 0
11, 1
11, 2
11. 3
11. 14 (Vos, it is compatible with the bank mod)

No Dialogue was deleted or changed just new topics/infos. The Main-Script and any other original Scripts remain unchanged.

The Silt strider operators Punibi Yahaz in Gnisis, Dilami Andrem in Molag Mar, and Seldus Nereadus in Khoum have had new destinations added to them. 

This Plug-in is INCOMPATIBE with ANY mod that changes the exterior of Tel Uvirith, like Green Uvirith. It is COMPATIBLE with any mod the changes the interior of Tel Uvirith.



There might be errors when loading an old save game that was created
before installing this plug-in. This happens, when the Player is in
one of the exterior Cells around Tel Uvirith, especially when other
Plug-in that modify this area are active. If you don't want to
start a new game, load a Save game where the player is in another
Cell like Balmora.


*****************************************************************

     3. INSTALLATION 

*****************************************************************
Unzip the files sraight onto the Hard dirve; ex "c:\".  Check �Clean Tel Uvirith Rebuilt� in the Morrowind launcher.

***************************************************************

     4. Notes

*****************************************************************
-Thanks
HUGE thanks to Nazz for making Gah-ruhn.
Thanks to Clone for the beautiful temple models.

-Warning:
This plug-in changes the exterior of Tel Uvirith drastically. If you have Green Uvirith or any similar mod loaded, things will get very weird.

-Playing this plug-in:
Pop it in a look around. Enjoy.


*****************************************************************

     5. VERSION

*****************************************************************

V 1.0:   The first try and I hope it works. 


------------------


Please send comments and bug reports to: Zurin_Arctus@juno.com


*****************************************************************

     6. CREDITS

*****************************************************************

Thanks to the following people and mods who, whether they know it or not, where instrumental to this mods formation.

"Gah-ruhn" by Nazz
(Several House Interior, some NPCs, "Blue Book" script)

"Green Uvirith" by ThaEgbird
(Gave me the idea to redo the exterior of Tel Uvirith)

"Sea of Destiny" by Clone
(The Temple exterior, and some interior entrance models)

"Indoril Gate House" by Aaron French AKA Veet
(For Indoril Gate House, duh.)

"Indoril/Almalexia models" by. Kothloth (TR)
(Excellent towers, walls, ground textures, and a nice Indoril well)

�Rugs and Tapestries Collection V 1.0� by. Lord Yig
(Got some nice rugs from it)

