File History - 08/OCT/2013 Spirithawke
File has no readme, data taken from:  http://forums.bethsoft.com/topic/1471910-req-telvanni-doors-mesh-issue/

#1 [[REQ] Telvanni Doors - Mesh Issue: post #1]
trancemaster_1988
Posted 28 August 2013 - 10:53 AM

    Members
    PipPipPip
    Diviner
    Joined: 20-June 06
    2597 posts

    Location:Valhall

So I noticed today while working on something for Rebirth, that the handle on the Telvanni doors has "some" issues that needs to be corrected (mesh/texture). If you want to see for yourselves, here's the proof: http://imageshack.us/photo/my-images/703/s804.jpg/

Would anyone be so kind to fix this issue?

Fixed: http://imageshack.us/photo/my-images/593/l7ho.jpg/

Download: http://www.speedyshare.com/6gtJn/Telvanni-Door-Without-Multicolored-Handle.rar
