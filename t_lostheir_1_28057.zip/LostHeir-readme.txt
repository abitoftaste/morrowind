Blades Quest: Prophecy Of The Lost Heir

Author: Emma
Movement script: TheOtherFelix, based on the original movement script by Grumpy.

During a fearful storm 15 years ago, a ship was wrecked off the coast of Khuul. Among the victims were Iliam Dren - the rejected firstborn child of the previous Duke Dren - and his wife and children. However, one of the bodies was never found: the mortal remains of Iliam's oldest son Artruhn are still missing.

Now, the ageing emperor Uriel Septim is worried about the violent Morrowind atmosphere and is concerned for the future for the Vvardenfell people. One night, he has a very strange dream. In his dream, Mara, the Goddess of Love, whispers to him, telling him that Artruhn might still be alive, and that he might have the powers to govern Vvardenfell and bring peace to the area. She also tells him that help from the Nerevarine is necessary if the search for Artruhn is to be successful.

The emperor has therefore now sent Caius Cosades' superior, the Blades' Very Special Agent Janicia Laboremus, to Balmora, with strict orders to persuade the Nerevarine to join her in her search for Artruhn. It's a battle against time - the rumours about the emperor's dream is all over the empire, and the corrupt relatives of the present Duke Dren have no wish for a new, righteous, government of the island...

You'll find Janicia Laboremus in Caius Cosades' Balmora house. As a skilled agent, she will of course never get stuck or disappear when travelling across Vvardenfell. All available companions in this mod use an enhanced version of the warping script that makes companions an asset instead of a burden. 

YOU HAVE TO BE NEREVARINE TO PLAY THIS MOD. 
Only as Nerevarine, you will be able to accompany Janicia and be introduced to the agents at the Blades' secret hideout. As Nerevarine, this mod should give you approx. 8-12 hours playtime, six new optional companions, all with their own distinctive personalities and stories, a number of sidequests and some new allies.

SAFE FOR PURISTS
I know many players dislike mods that determine the future of Morrowind and/or messes with the TES lore. Therefore, this mod has been created with TWO OPTIONAL ENDINGS, and in the end it's up to you to decide the outcome of the story. I have also carefully avoided using original Morrowind npc's in this mission; some of them might have information to give you, but the main characters are all imported into Morrowind by me.

THE COMPANIONS
At the Secret Hideout of the Blades, you will meet a number of agents that you can use as optional companions. Many of them will also have side quests for you. (Janicia is the only one that you actually have to bring with you in order to complete the main quest). 
You will be able to develope your relationship with the agents as time passes by. This is mostly triggered by weather conditions, so in order to make things happen, you'll have to bring the agents along with you. You can keep the companions forever and ever if you want to. The story will end, but they will still be there for you.
For companions of the opposite sex to your PCCharacter, you will sooner or later be given an option to choose if you want them just as a buddy or if you want them as girl/boyfriends. It's up to you to choose - but if you choose more than one as a girl/boyfriend, you will sooner or later end up in big trouble, as they are "interacting" and your decisions will be reflected in the behavior of all the npc's. 
If you use the topic "about my skills" and decide to tell the agent what you have learnt lately, every agent will adapt their skills so that they will fit the level of your PCcharacter. All of them will do that in different ways - some are significally weaker than your character, others are more equal to you. All of them also have their personal "peak skill/s", which will not be altered by any level script. The acrobatics skills for the companions are really high, and have been set like this in order to further improve their following abilities.
One important new function: the agents are "smarter" marksmen than any previous companions, as they automatically switch from marksman weapon to melee weapon when in melee combat.

INGAME "SPOILERS"
Although Janicia will give you valuable suggestions, it is up to you to fulfil this quest. If you don't know what to do, you can often ask Janicia if she has "any suggestions". She will then give you a clue, but her disposition towards you will drop significantly, as she indeed believed you to be smart enough to find things out without her help.


-------------------------------------------------------------------------

CREDITS

--------------------------------------------------------------------------

First of all, I want to give my VERY SPECIAL THANKS to two fellow modders. Without their help and constant support, I would never have been able to release a mod with all the functions added to these companions:
GRUMPY, the developer of the warping movement and also a great modder friend. Since autumn 2002, we have been constantly debating, arguing and laughing together, and without his support, ideas and feedback, modding wouldn't have been half as fun as it is today.
THE OTHER FELIX, a great modder friend, who has added so much of his creativity and knowledge and so many good suggestions and enhancements to every aspect of this mod, as well as to my other mods. Among many other things, he has taught me how to deal with the voice part of the dialog, he has created the telepathy script and he has further enhanced the movement script, for instance by upgrading the levitating and swimming part and making it possible for companions to levitate or slowfall through doors without taking damage.

I also want to give my VERY SPECIAL THANKS to one Morrowind player, ROBEAST1965, who has given me constant support, feedback and friendship, who has inspired and encouraged me to further improvements of this mod, and last but not least proofread and corrected more than 300 pages of dialog.

I also want to thank the creators of the beautiful heads and hairs that I have used in this mod:
JANICIA LABOREMUS: imperial head made by Rhedd, hair made by Gorg (Hairpack II)
INSELA NORRHJUM: nord head by Zuldazug, hair made by Rhedd.
HOLLY BELSEY: redguard head and hair by Zuldazug
BUDDY BELSEY: redguard head by Zuldazug, Morrowind original hair.
MARK ST.ROUBELLE: breton head and hair made by Rhedd
GREENFELD: nord head and "hair" made by Rhedd
AI LEGRAND: breton head by Don Salus (a very special thank to you, Don Salus, for letting me use a yet not released head from your upcoming face pack III. Like the rest of the modding community, I'm very much looking forward to your new work!!) and hair by DarkSharp, included in ZeroTheHero's NPC replace 3.50

You will find all the beautiful heads and hairs at these sites:
Rhedd's heads: http://home.wnm.net/~bgriff/MW_Home.html
Zuldazug, Don Salus, ZeroTheHero: http://www.khalazzaprod.fr.st/
Gorg's hairpacks: http://morrowind.unforgottenrealms.net/
(If you are looking for good face mods, you should definitely also check out the heads made by Astarsis, Nomad, CanadianIce and Sheikizza.)

The skills-script is basically the same as TheLys has used in the "Give Your Orders"-mod.
The Teleport Ring script is based on and reworked from the 18 destinations teleport ring script made by Scott Fischer.
The step-aside-function was introduced by Dixon in his companion Hilda-mod, and he has kindly offered me to use it.

Without the help from good playtesters, it would be almost impossible to keep a mod bugfree. I can not swear that this mod indeed is bugfree, but thanks to the help from Llorrac, Conager1, Straydog, Sunsi, Fernelf, Andrea, Zor_Valachan, Beardo and Robeast1965, many bugs and errors have been avoided. Thank you ever so much for your help, support, feedback and friendship!

Actually, there are so many people I would like to thank - people that I have met at the forums, people that have given me support, feedback and suggestions. I'm afraid that if I specify any more names here, I will forget someone really vital, and therefore I'll stop right now and only mention those who have been directly involved in this mod.



----------------------------------------------------------------------------

INSTALLATION: 

----------------------------------------------------------------------------

ALWAYS MAKE A SAFETY COPY OF YOUR SAVED GAME BEFORE ADDING ANY NEW MOD, THIS ONE INCLUDED!!!!
Just UnZip to your Morrowind-library.

--------------------------------------------------------------------

TROUBLE SHOOTING:

-------------------------------------------------------------------- 

INSTALLATION:

1) THE NPC'S HAVE AN EXCLAMATION-MARK INSTEAD OF A HEAD: This is a rather common problem. When you unzipped the files, they ended up
inside a folder in your data files section, right? (This happens all the
time, as far as I know it's because you use an US/british version of Windows
while I use a scandinavian). And then you tried to drag each texture and
meshes manually into their right folders?
What you should do is this:
Move the new folder you got when unzipping to the desktop. Double-click on
it. You'll find one esp-file, one meshes folder and one textures folder
inside. DROP the meshes folder into your data files section. It should now
automatically merge with the existing meshes folder (probably you will be
asked a question about existing files, say yes to this). DROP the textures
folder into the data files section. It should also merge with the existing
textures folder. Move the esp-file to the data-files section. You're ready
to go, and now everything should work just fine.

GAME PLAYING:

1) When flying over the ocean together with your companions, you will of course sometimes be attacked by cliff racers. Your companion will fight them, but after the fight he/she might be standing in the air, waving the sword, refusing to follow you. This is caused by the angry slaughter fishes in the water below; he/she want to fight them, but can't determine their positions. You can either go down and start fighting them, yourself, and the companion will follow you. Or you can use the telepathy ring, to make the companion stop fighting and instead follow you.

2) If something should happen with the "companion sharing" option, you can always get it back by telling the companion that you want to be alone for a while. When you ask her/him to join you again, companion sharing will automatically be added. 

3) PLEASE NOTE: If you are separated from a companion for more than 72 game hours, the Morrowing original 72 game hours-bug will be executed, and the companion's skills will be reset back to initial value. In this mod, you can fix this by bringing up the topic "about my skills" and tell the companions about what you have learnt lately.
The telepathy ring is also affected by the Morrowind 72 game hours bug. I.e. if you have been separated from one of your companions for more than 72 game hours, the ring will consider him/her as "dead". But as soon as you meet the companion again, the telepathy ring will also start to function. After the first missions, you will always be able to teleport the companions back to the Secret Hideout of the Blades by talking to AI LeGrand.




-----------------------------------------------------------

e-mail: emma9158@hotmail.com 
------------------------------------------------------------   



Other mods by me:
Witchgirl Adventure ver. 1.1 (Tribunal required)
Laura Craft Romance and Adventure Mod ver 1.3 (Tribunal required)
Girlfriend Breton ver 2.1
Tribunal Girlfriend Breton ver 2.1
Boyfriend Imperial ver 2.1
Tribunal Boyfriend Imperial ver 2.1

Some of my mods are also available in german and french
