Companions Buddy & Holly
Requires: Tribunal

Author: Emma
Movement script: TheOtherFelix, based on the original movement script by Grumpy.

At Eight Plates in Balmora, the Blades' agents Buddy and Holly are waiting for you, ready to be your companions. 

PLEASE NOTE: 
Buddy and Holly originally belongs in my quest mod "Blades Quest: Prophecy of The Lost Heir". As you have to be Nerevarine in order to play "Lost Heir", I decided to make a separate companion mod with two of the Blades agents.

THIS MOD SHOULD NEVER BE USED BE USED TOGETHER WITH "BLADES QUEST: PROPHECY OF THE LOST HEIR".
RUNNING THE MODS TOGETHER WILL DEFINITELY CAUSE INCOMPATIBILITY ISSUES.

You should be able to safely use this mod until you decide to add "Lost Heir" instead. In order to avoid problems when upgrading to "Lost Heir", I have changed the ID-names as well as names of scripts an journals. However, the dialog is taken from "Lost Heir", so if you try to run the mods together, this will cause dialog errors.

This is a pure companion mod - there are no quests connected to Buddy and Holly, and you can not develope your friendship with them. They will tell you some facts about themselves, but in order to get to know them better, you will have to play "Lost Heir" instead.



Some of the features:

- BRANDNEW!!! Buddy & Holly will automatically switch from marksman to melee weapons if engaged in close combat with an enemy. (If Holly has a really good marksman weapon that she has choosen "on her own", she might not do so, as marksmanship is one of her peak skills). This feature was introduced with "Blades Quest: Prophecy Of The Lost Heir".

- Grumpy's original movement script has been further enhanced. Thanks to TheOtherFelix is Buddy & Holly among other things able to fight during levitation. 
- A number of combat options: You can a) order Buddy & Holly to stay out of fight. b) order Buddy & Holly to cover up from a distance, using spells or marksman weapon c) order them to use marksman weapons. (You don't have to remove their other weapons in order to make them use marksman weapons)
- Buddy & Holly literally talks to you when in dialog mode
- Buddy & Holly don't like bribing. But you will find other ways to raise their disposition towards you. Buy them a drink, give Holly a flower or help Buddy find new ingredients to his botanic collection. 
- Buddy & Holly will be able to communicate with you by telepathy (script by TheOtherFelix).They also have an "emergency teleport ring" for instant teleporting to Caius Cosades' house.
- Buddy & Holly will level with the player, but in different ways (Buddy is stronger, Holly is weaker). They also have two "peak skills" each, that will always be high and not influenced by the level of the player.
- Buddy & Holly will tell you about their current skills.
- The infamous Bethesda-bug that causes companion to take damage if passing through a door with slowfall active has been resolved. Same goes for the bug that causes companion to disappear if levitation is active when passing through a door. (Please note: you do NOT have to use the "Companionfriendly doors mod")
- Buddy's and Holly's swimming abilities have been improved.
- Buddy and Holly will automatically report if they are injured and need to heal themselves.
- The step-aside-function has been added.
- Both Buddy & Holly will dance with you.



-------------------------------------------------------------------------

CREDITS

--------------------------------------------------------------------------

First of all, I want to give my VERY SPECIAL THANKS to two fellow modders. Without their help and constant support, I would never have been able to release a mod with all the functions added to these companions:
GRUMPY, the developer of the warping movement and also a great modder friend. Since autumn 2002, we have been constantly debating, arguing and laughing together, and without his support, ideas and feedback, modding wouldn't have been half as fun as it is today.
THE OTHER FELIX, a great modder friend, who has added so much of his creativity and knowledge and so many good suggestions and enhancements to every aspect of this mod, as well as to my other mods. Among many other things, he has taught me how to deal with the voice part of the dialog, he has created the telepathy script and he has further enhanced the movement script, for instance by upgrading the levitating and swimming part and making it possible for companions to levitate or slowfall through doors without taking damage.

The beautiful redguard heads are created by Zuldazug, you'll find his work at: http://www.khalazzaprod.fr.st/

The skills-script is basically the same as TheLys has used in the "Give Your Orders"-mod.
The step-aside-function was introduced by Dixon in his companion Hilda-mod, and he has kindly offered me to use it.

Without the help from good playtesters, it would be almost impossible to keep a mod bugfree. The functions used in this mod has been tested in "Prophecy of The Lost Heir" and "Laura Romance" by  Llorrac, Conager1, Straydog, Sunsi, Fernelf, Andrea, Zor_Valachan, Beardo and Robeast1965. Thanks to them, many bugs and errors have been avoided. An extra thank you to Robeast1965, who has also proof-read and corrected Buddy's and Holly's dialog!


----------------------------------------------------------------------------

INSTALLATION: 

----------------------------------------------------------------------------

ALWAYS MAKE A SAFETY COPY OF YOUR SAVED GAME BEFORE ADDING ANY NEW MOD, THIS ONE INCLUDED!!!!
Just UnZip to your Morrowind-library.

--------------------------------------------------------------------

TROUBLE SHOOTING:

-------------------------------------------------------------------- 

INSTALLATION:

1) THE NPC'S HAVE AN EXCLAMATION-MARK INSTEAD OF A HEAD: This is a rather common problem. When you unzipped the files, they ended up
inside a folder in your data files section, right? (This happens all the
time, as far as I know it's because you use an US/british version of Windows
while I use a scandinavian). And then you tried to drag each texture and
meshes manually into their right folders?
What you should do is this:
Move the new folder you got when unzipping to the desktop. Double-click on
it. You'll find one esp-file, one meshes folder and one textures folder
inside. DROP the meshes folder into your data files section. It should now
automatically merge with the existing meshes folder (probably you will be
asked a question about existing files, say yes to this). DROP the textures
folder into the data files section. It should also merge with the existing
textures folder. Move the esp-file to the data-files section. You're ready
to go, and now everything should work just fine.

GAME PLAYING:

1) When flying over the ocean together with your companions, you will of course sometimes be attacked by cliff racers. Your companion will fight them, but after the fight he/she might be standing in the air, waving the sword, refusing to follow you. This is caused by the angry slaughter fishes in the water below; he/she want to fight them, but can't determine their positions. You can either go down and start fighting them, yourself, and the companion will follow you. Or you can use the telepathy ring, to make the companion stop fighting and instead follow you.

2) If something should happen with the "companion sharing" option, you can always get it back by telling the companion that you want to be alone for a while. When you ask her/him to join you again, companion sharing will automatically be added. 

4) PLEASE NOTE: If you are separated from a companion for more than 72 game hours, the Morrowing original 72 game hours-bug will be executed, and the companion's skills will be reset back to initial value. In this mod, you can fix this by bringing up the topic "about my skills" and tell the companions about what you have learnt lately.
The telepathy ring is also affected by the Morrowind 72 game hours bug. I.e. if you have been separated from one of your companions for more than 72 game hours, the ring will consider him/her as "dead". But as soon as you meet the companion again, the telepathy ring will also start to function. As a safety backup Buddy and Holly will give you their "emergency teleport rings", that will teleport them to Caius Cosades' house in Balmora, regardless how many hours you have been separated.



-----------------------------------------------------------

e-mail: emma9158@hotmail.com 
------------------------------------------------------------   



Other mods by me:
Blades Quest: Prophecy Of The Lost Heir (Tribuanl required)
Witchgirl Adventure ver. 1.1 (Tribunal required)
Laura Craft Romance and Adventure Mod ver 1.3 (Tribunal required)
Girlfriend Breton ver 2.1
Tribunal Girlfriend Breton ver 2.1
Boyfriend Imperial ver 2.1
Tribunal Boyfriend Imperial ver 2.1

Some of my mods are also available in german and french
