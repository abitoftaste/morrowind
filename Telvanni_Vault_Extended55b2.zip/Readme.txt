Telvanni Vault Extended

	This mod extends the Telvanni Vault in Vivec. This mod's architecture fits seamlessly into the rest of the vault, it does not add any uber items, and there are plenty of guards to give you a challenge in stealing from it.

	Please report any bugs to me, I will gladly correct them. I have cleaned this mod with TESAME, so it shouldn't conflict with any other mods that you have.

	Thank you for downloading, Serenia.