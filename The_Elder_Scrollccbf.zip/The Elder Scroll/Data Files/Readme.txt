This is the elder scroll mod, which adds 1 new ncp, 1 new ruin, a popular new book, a minor quest, and one of the fabled elder scrolls of legend.

All work by The_Drunken_Mudcrab; only original Textures and Meshes used.



ROUGH WALKTHROUGH

------------------
There is a new book out regarding the topic of a lost dwenmer ruin. This is not required for the quest and has been added singularly for lore

To begin, seek out the new oddly dressed patron at the End of the world bar and inn in Dagon Fel.

This man starts a quest to go to a ruin out in the middle of the ocean, under the same name as the book.

The ruin is far east of Dagon Fel, and you must swim a considerable distance to get there.

Once you get there, you may realise that the ruin is completely underwater.

-------------------------------------------------------------------------------------


These items are needed/reccomended to get through the ruin to the elder scroll -

1. Waterbreathing potion(s)

2. Levitation

3. Ability to access a 90 locked door


4. Ability to kill a 30 level boss

Once you kill the "boss" the elder scroll is yours to keep!
-------------------------------------------------------------------------------------------