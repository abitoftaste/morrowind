*****************************************************************

     The Elder Scrolls III
           MORROWIND: 
      RheddHeads Nord_M01
		
*****************************************************************

Index:
1. Installation
2. Playing the Plugin
3. Save Games
4. Changing the Face of an Existing Character
5. Credits & Usage



*****************************************************************

     1. INSTALLING THE PLUGIN

*****************************************************************

To install the plugin, unzip the files into the "Morrowind" directory. 

UPDATE: This plugin was developed using version 1.2.0722 of Morrowind.
It should run correctly on other versions but has not been tested.


*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

From the Morrowind Launcher, select Data Files and check the box 
next to the RheddHeads Nord_F01.esp file.

This plugin adds three playable Nord male heads with variants, one playable
hairstyle in various colors, and one bald hairstyle.

*****************************************************************

     3. Save Games

*****************************************************************

This plugin will not invalidate your old saved games. If you save 
your game while this plugin is loaded, you may encounter error messages 
when you reload the saved game without the plugin. But you will be
able to continue on with the original game.


*****************************************************************

     4. Changing the Face of an Existing Character

*****************************************************************

To change the face of your existing character without starting a new game, 
open the console and type "enableracemenu". Choose your new face and hair. 
Changing your race will cause temporary problems that should resolve 
themselves when you reload. Always save your game first in case of 
unpredictable errors and save afterwards in a new file.

Enableracemenu will only work once. If you want to change your face again 
you must first exit Morrowind and reload your game. 

*****************************************************************

     5. Credits & Usage

*****************************************************************

Original face and hair models by Rhedd.
Original face and hair textures by Allerleirauh.

bgriff@wnm.net
http://home.wnm.net/~bgriff

You may use and distribute the models and textures freely without 
additional permission as long as the above credits and contact information 
are included and they are distributed free of charge.