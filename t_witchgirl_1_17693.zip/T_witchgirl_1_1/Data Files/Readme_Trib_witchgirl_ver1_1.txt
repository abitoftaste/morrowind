--------------------------------------------------------------------------------------------------

The Witchgirl Adventure. VER 1.1 - TRIBUNAL IS REQUIRED
PLEASE READ THIS README-FILE!!! IMPORTANT INFORMATION, ESPECIALLY FOR THOSE WHO ARE ALREADY USING VER. 1.0 

--------------------------------------------------------------------------------------------------
Author: EMMA
Movement script: THEOTHERFELIX, based on the original warping script by GRUMPY
--------------------------------------------------------------------------------------------------

PLEASE NOTE: THIS IS NOT WITCHGIRL ADVENTURE PART 2. THIS IS AN UPGRADED AND ENHANCED VERSION OF WITCHGIRL PART 1, WHICH I WILL USE AS A PLATFORM TO CONTINUE ON PART 2 DURING THE AUTUMN 2003

--------------------------------------------------------------------------------------------------

Hours of gameplay, a dangerous RESCUE MISSION, a strange ARTIFACT, ever-lasting COMPANIONSHIP, odd CHARACTERS and ROMANCE for male as well as female PC Characters - you'll find it all in the Witchgirl Adventure.

THIS IS A TRIBUNAL VERSION, INCLUDING SHARING OPTION AND WARPING MOVEMENT SCRIPT. A Morrowind version 1.0 is also available, but this will not be upgraded to ver 1.1.

THE WITCHGIRL:
Tired of the lonely life as a Morrowind adventurer? Get enchanted by Morgana de Hex, the Ald'Ruhn witchgirl. She's a talkative Breton, who would just love to be your companion. And, apart from her short sword abilities, she knows a lot of useful magical tricks that surely makes her a worthy partner. Far from being your obedient slave, she has a rather lousy temper and might curse you from time to time. But you will soon find out that there are ways to make her as happy as a songbird, too... 
You'll find Morgana de Hex outside her house close to the Ald'Ruhn temple. Visit her home together with her, and she might even let you meet a very odd relative of hers...
Morgana and her friends have DIFFERENT DIALOG OPTIONS depending on the sex of your PC Character. With a female character, Morgana will be your best friend, always ready to share a bottle of Skooma or lend you some money. With a male character, she might offer more than that - it you play your cards well, that is.
PLEASE NOTE: Morgana has some very powerful magical abilities in her hands. If your have a low-level character, it might be wise NOT to let her summon something really nasty, as your character might get hurt or even killed by mistake. Luckily, you can give her detailed instructions about how to fight, and she will - hopefully - obey your orders.

THE ADVENTURE:
After being properly introduced to a very special relative of Morgana's, you will be thrown into a story line that will take you all over the Morrowind isle. You will make new friends and new enemies, you will hear tales about lost artifacts, and you will encounter a person who might be a danger to all the people of Vvardenfell. At least 6-8 hours of gameplay lays ahead of you.
Don't forget to talk to Morgana and her friends now and then. Certain circumstances might alter their standard greetings, and there might be information that you don't want to miss. You can complete the whole adventure on your own, leaving Morgana and her friends behind. But certain aspects of the adventure will be lost - such as romance, for instance.  
After finishing the adventures, some of the NPC's involved will be delighted to stay on as your companions (and perhaps more than that), forever and ever.
You will also meet a new kind of Morrowind character - the NPC personal trainer, who will help you to develop your companion's abilities in whatever way you may choose. 

 
HINTS: After accepting Morgana as your companion, return to her house together with her. There, you will be introduced to someone who, after being reassured that you're a true friend of Morgana's, will ask for your help.

------------------------------

VER 1.1 - NEW FEATURES:

------------------------------
1) Thanks to the enhanced movement script by TheOtherFelix, your companions will now fight during levitation. The infamous bug that causes companions to disappear when passing through a door while levitating has been fixed, and so has the bug that causes companion to take damage when passing through a door with slowfall spell active. (You do not need to use the companionfriendly doors plugin). The companions is not only excellent followers in the air, but also when swimming.
2) New combat options: You can a) order your companions to teleport back to Ald'ruhn if they gets severely injured b) order them to stay out of fight, until either they or you get severely injured (this is a brand-new approach, introduced in "Laura Craft Romance and Adventure mod ver 1.1" basically using dialog instead of scripting, which should NOT cause any errors in the enemies' attack behaviour. In this version, the feature should work also when using Giants) c) Leif can be ordered to guard one spot and with a marksman weapon, he will be able to attack from distance during the fight (please note that you have to remove his other weapons in order to make him use the marksman weapon)
3) After a while, a relative of Morgana's will provide you with telepathy rings (telepathy script by TheOtherFelix) that will make it possible for you to communicate with your companions during fight or while separated.
4) The step-aside-function, introduced by Dixon in his Companion Hilda mod, has been added. A very handy function whenever the companions are blocking your way.
5) Your companions won't be happy if you try to bribe them. Instead, there are other ways to raise their dispositions. As for Morgana, you will be able to FLATTER her (topic Moon Sugar), the outcome is not based on speechcraft but on luck and Random100. I.e. your words might make her happy, but she can also become rather angry with you. Leif will mostly appreciate if you ask him to tell you one of his infamous warrior stories.
6) The dancing girl animation has been added.
7) The companions will "know" if you have a weapon pointing at them, and this may influence the dialog. They will also "know" if the PCCharacter is nude and if he needs healing.
8) The companions will be happy to tell you about their current skills.
9) The area of Morgana's less harmfull spells have been reduced in order to prevent the PCCharacter from getting injured. She also has a couple of new fighting spells, for instance "paralyze", that she might - or might not - use now and then.
10) The companions will automatically report if they are injured and need healing.
11) The companions will now also greet you with voices, and with several different greetings, depending on their current mode and the gender of your PCCharacter.
	

IMPORTANT!!!
PLEASE NOTE:
Compatibility: This plug-in is clean, tested + running smoothly together with a wide range of different plug-ins. HOWEVER, there is one embarassing exception. Due to similar dialog "topics", "Witchgirl" does not run smoothly together with my own OLDER companion-plugins, "Girlfriend" and "Boyfriend" ver. 1.0, 1.1, 1.2, 1.2.1 (i.e. certain topics will never be highlighted).  However, this mod runs smoothly together with Girlfriend/Boyfriend-plugins ver 2.0-2.1 as well as Laura Craft Romance and Adventure mod.

-------------------------------------------------------------------------

CREDITS

--------------------------------------------------------------------------

First of all, I want to give my VERY SPECIAL THANKS to two fellow modders. Without their help and constant support, I would never have been able to release a mod with all the functions added to these companions:
GRUMPY, the developer of the warping movement and also a great modder friend. We have been constantly debating, arguing and laughing together for several months, and without his support, ideas and feedback, modding wouldn't have been half as fun as it is today.
THE OTHER FELIX, a great modder friend, who has added so much of his creativity and knowledge and so many good suggestions and enhancements to every aspect of this mod. Among many other things, he has taught me how to deal with the voice part of the dialog, he has created the telepathy script and he has further enhanced the levitating and swimming part of the movement script.
 
Thanks to Rhedd's beautiful heads, Morgana and Leif looks really smashing. (Rhedd's readme files is enclosed). 
The npc-movement in the companion-script is based on an idea from Reznod that has been developed by Grumpy, who has kindly offered me to use it in my plugins. Some additional enhancements, suggested by Devlor, has also been added. Finally, TheOtherFelix has made some extraordinary enhancements concerning particularly the levitating, swimming and levitating/fighting parts of the movement script. TheOtherFelix has also suggested a number of other vital scripts, for instance the telepathy script.
The skills-script is basically the same as TheLys has used in the "Give Your Orders"-mod.
The "Lover's ring" script is based on and reworked from the 18 destinations teleport ring script made by Scott Fischer.
The step-aside-function was introduced by Dixon in his Companion Hilda mod, and he has kindly offered me to use it in this mod.
I would also like to add my special thanks not only to Grumpy and TheOtherFelix, but also to GarryB (who has also corrected my lousy english grammar), Beardo, Devlor, Razorwings18, Emil, Dinkum Thinkum, Fernelf, Sunsi and Robeast for giving me help, support and numerous of valuable suggestions.

-----------------------------------------------------------------------------

INSTALLATION INFORMATION: EXTREMELY IMPORTANT IF YOU ARE UPGRADING FROM VER 1.0!!!!!!!

------------------------------------------------------------------------------

ALWAYS MAKE A SAFETY COPY OF YOUR SAVED GAME BEFORE INSTALLING OR UPGRADING ANY MOD, THIS ONE INCLUDED!!!!

NEW USERS:
----------

Extract the zip-folder to your Morrowind Data Files library. When using an European Windows-version, the files should end up in the right libraries. 
If not, all the files will end up in a folder inside your data files section. If this happens, do as follows:
Move the new folder you got when unzipping to the desktop. Double-click on
it. You'll find one esp-file, one meshes folder and one textures folder
inside. DROP the meshes folder into your data files section. It should now
automatically merge with the existing meshes folder (probably you will be
asked a question about existing files, say yes to this). DROP the textures
folder into the data files section. It should also merge with the existing
textures folder. Move the esp-file to the data-files section. You're ready
to go, and now everything should work just fine.

UPGRADING FROM VER. 1.0
-----------------------

You won't have to re-start the Witchgirl Adventure in order to use this upgraded version. However, if you are using ver.1.0, or if you have earlier on been using ver 1.0 in you ongoing game, you will have to spend a few minutes on upgrading, else some of the new enhancements won't work properly. 
What you should do is this:

a) Ingame, tell Morgana's grandpa to leave for a while. Close the door to her study (these steps is recommended in order to prevent the common doubling bug when upgrading.) Leave the Ald'ruhn area. MAKE A SAFETY COPY OF YOUR SAVED GAME!!!
b) Place the copy of your savedgame in the Morrowind data files folder. Rename your saved game from an ess-file to an esp-file (right-click on the save and hit rename.Exchange the letters ".ess" with ".esp", hit enter).
c) open up TES Construction set, highlight your renamed esp-file and mark it with "X". Hit the "details"-button (don't load the esp, just hit details).
d) In the details-list, look for and highlight a line called "NPC-1AA_Morgana". DELETE this line. Use the "delete"-tab. You will get a question if you really want to delete the line, say OK to this. If you look in the details list, you will now see a "|" in front of the NPC-1AA_Morgana-line. This means that you have successfully deleted the line. Now, look for a line called "NPC-1AA_Leif". DELETE this line as well. Please note: there is also a line called "NPCC-1AA_Morgana" and "NPCC-1AA_Leif". DON'T touch those lines. 
e) Close the TES Construction set (do not save or load the esp-file, just close TES construction set)
f) Go back to your data files folder and find the saved game esp. Right click and hit rename. Exchange the letters ".esp" with ".ess".
g) place your updated ess-file among your saved games. Now, you are ready to play.

h) When you meet Morgana and Leif after upgrading, they will probably not have the sharing option active. In order to regain it, do like this: Tell them that you want to be alone for a while (topic together). Leave Dialog window. Go back to dialog window and topic together. Ask them to join you. This should bring back the sharing option. (If you for other reasons should lose the sharing option during the game play, you can always get it back  by doing like this).



-----------------
TROUBLE-SHOOTING 
-----------------

A common problems with companions used together with Tribunal is that they tend to increase the distance to the PCCharacter during the gameplay. I am no expert concerning this issue, but others have explained to me that it should help to let the PCCharacter take a long sleep (+24 hrs). After that, the companions should get closer again.

When flying over the ocean together with your companions, you will of course sometimes be attacked by cliff racers. They will fight them, but after the fight they might be standing in the air, waving their weapons, refusing to following you. This is caused by the angry slaughter fishes in the water below you; they want to fight them, but can't determine their positions. You can either go down and start fighting them, yourself, and they will follow you. Or you can use the telepathy rings, to make them stop fighting and instead follow you.

If something should happen with the "companion sharing" option, you can always get it back by telling the companions that you want to be alone for a while. When you ask them to join you again, companion sharing will automatically be added. 

PLEASE NOTE: If you are separated from a companion for more than 72 game hours, the companion's skills will be reset back to initial values. Therefore, I would recommend that you try to pay a visit to Leif and Morgana within these 72 game hours.


----------------------------------------------------------------------------
IN-GAME TROUBLE-SHOOTING - - - WARNING - - - - SLIGHT SPOILERS!!
----------------------------------------------------------------------------

This far, I have only encountered one specific problem. Out of the approx 500 times I have started this game, it has happened twice that the very initial quest (when making friends with Morgana) hasn't proceeded as expected. (I.e. one of the species she asks me to kill is hidden somewhere in her house, and she won't be satisfied until I have killed the lot). Twice out of 500 isn't very much, and as this happened only 2-3 minutes after starting the witchgirl adventure, the simple solution is to reload the game. Then, all the species will surely be there.

At one point you'll visit someone called Heliessa. If you for some reason have to reload the game and re-visit her, she will... hrm, act in a certain way a bit too early. However, this doesn't alter anything significant. (There is alas nothing to do about this "error", as it's caused by the Morrowind saving system)

At one occasion, you are expected to walk with three companions, one of those a low-level character, down to the Vivec underworks. This can be kind of tricky (everyone who have ever used a companion will surely understand what I mean), and it might be better to leave all but the low-level character behind for a couple of minutes.



Apart from this, I haven't really had any difficulties at all. But as the dialog is really extensive, there is always a risk that different plugins can interfere with each other. If so, please report to me at Emma9158@hotmail.com. 

