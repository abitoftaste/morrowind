The Elder Scrolls, Chapter One: Arena
By Meej-Dar
September 28, 2011

REQUIRES: Tribunal and Bloodmoon

This is a demo of an upcoming mod made by me, Meej-Dar, and perhaps a few others. As of now, it's just me, though. This mod aims to let you play the original Elder Scrolls game with Morrowind graphics. As this is just a demo, you will only get to escape from the Imperial Dungeons.

In the Census and Excise Office in Seyda Neen, on the table next to Sellus Gravius, you will find the Arena Amulet. Equip it, and it will ask you if you wish to be transported to the Imperial Dungeons. Click 'yes' and off you go.

The key to the cell is on the small platform on the northwest side of your cell. Once outside, you will face rats and goblins, and you may even find some treasure (although right now the 'treasure' is just acting as a marker for the real treasure, all you'll find is food). You are trying to escape the dungeons, and the only way you can do that is to go through the Shift Gate in the southwest corner of the dungeon. Although Ria Silmane recommends you explore and loot the dungeons, as Jagar Tharn has stashed stolen treasures from the Imperial Treasury down here (again, all the treasure from the Treasury is food right now).

As I've said, this is just a demo, a teaser, something to whet your appetite before the big mod itself comes out. Plus, this is the first one I've EVER made. Well, I've made a few that I use for myself, but those were just houses and the like.

So have fun, and remember: Bring a torch.
