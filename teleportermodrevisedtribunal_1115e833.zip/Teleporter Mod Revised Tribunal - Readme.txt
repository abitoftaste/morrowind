*****************************************************************

     The Elder Scrolls III
           MORROWIND: 
Teleporter Mod Revised Tribunal Plugin
		
*****************************************************************

Index:
1. Installation
2. Playing the Plugin
3. Save Games
4. Extended Information
5. Original Script


*****************************************************************

     1. INSTALLING THE PLUGIN

*****************************************************************

To install the plugin, unzip the files into the Morrowind/Data Files
directory. 

This plugin should work with any version of Morrowind. You may 
receive a master file/plugin incompatibility error when run 
with prior/future versions, but the plugin will work correctly.


*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

-From the Morrowind Launcher, select Data Files and check the box 
next to the "Teleporter Mod Revised Tribunal.esp" file.
-Go to Seyda Neen, Census and Excise office
-Open the small chest on the bottom shelf (lock level 1, lockpick beside it)
-Put the Ultimate Teleporter ring into your inventory
-Drop it on your character as if to equip it from your inventory
-Travel to 63 locations in Morrowind, _including_ the House Strongholds
you can build (very handy, since these are all in the middle of nowhere)
and 1 location from Tribunal.


*****************************************************************

     3. Save Games

*****************************************************************

This Plugin will not invalidate your old saved games. If you save 
your game while this plugin is loaded, you may encounter error messages 
when you reload the saved game without the plugin. But, you will be
able to continue on with the original game.

*****************************************************************

     4. Extended Information

*****************************************************************

Original Script Author: Unknown
Secondary Modifier: Kenneth Geddings Jr. (aka Evenios)
Tertiary Modifier: Alarys

Contact information:
alarys@hotmail.com
Please make sure to include "Ultimate Teleporter" in the subject, or it won't get past my spam filter. DO NOT expect any support from me, I am providing contact information out of common courtesy in case something is terribly broken.


This mod adds a teleportation ring called the "Ultimate Teleporter" to the game. It is based on previous work by an unknown script writer and Evenios. Originally, it allowed transport to 57 different locations (including all three areas where the House strongholds are build) and I found it an invaluable tool for getting around quickly. With the release of Tribunal, I decided to add the Mournhold Royal Palace Reception Area, and fill out a few more in Vardenfall, bringing the grand total to 64 locations.

You can find the "Ultimate Teleporter" in Seyda Neen, in the Census and Excise Office, which is where you begin the game. It is in the small locked chest (lock level 1) on a bottom shelf where the game has you practice your lockpick skills during the introductory tutorial. You can safely take anything out of this chest (there is no one near by, nor are the contents marked as belonging to anyone, so you won't lose the teleporter if you are caught stealing). NOTE: this is NOT the small chest on the table beside Socucius Ergalla!

If you add this mod to an existing save game, the Ultimate Teleporter will be in the same place, but the lock will be reset (even if you previously opened it) so do not be alarmed. Just open it again. Anyone should be able to open a level 1 lock ;-) I even graciously added a lockpick right beside the chest in case you didn't have one, or did not have an open spell! I think of everything ;-)

Use the ring by dropping it on your character as if to equip it. Note that you cannot assign a hotkey to this item and expect it to work properly (the act of "equipping" the ring is what triggers the script, so if you assign it to a hotkey, it will work once, but not again, until you unequip it since it is already "equipped" if that makes sense). For best results, just equip it from your inventory.

This mod should work even with an original install of the game, with no patches, or with any subsequent versions, including Tribunal. You may get an error message about "one or more modules not finding the correct versions of their master files". You can say "yes" to continue and everything should work fine. If you want to get rid of that message, merely open the mod in the TES Construction Set, and immediately hit "save". After that, you won't see the message. If you have other mods installed, you may have to do this for them as well. Note, if you patch up the game, you may need to do this again.

Please be aware that the Ultimate Teleporter allows unconditional teleportation to a variety of dangerous areas. When you appear, there should not be anything dangerous that will make Adventurer Jelly(TM) out of you immediately, even if low level. You should at least have enough time to port out of the area if you made a mistake. Exercise caution! Teleporting to Dagoth Ur while level 1 equipped with your spiffy iron dagger and clothes is probably a Bad Idea.

Finally, this mod will definitely change the way you play the game. Much of the appeal to Morrowind is the exploration aspect, so please be aware that this mod could seriously compromise that for you. However, there are certain quests where there is a _tremendous_ amount of slogging around, and if you see one more cliff racer you'll scream... Basically what I liked was that I could wander about at my leisure and see the sights, but get places quickly when I wanted to. It was the best of both worlds in my opinion.

I hope you enjoy it ;-) Adventure forth!


Known Issues:

Starting a New Character

-DO NOT use the teleporter to skip out of the introductory tutorial and quest giving sequences in the Census office. I don't know how this might affect your game. It's best to only use the ring after you are permitted to leave the Census office, and are standing in Seyda Neen, ready to begin your adventure.

Tribunal NOT Installed

-If you do NOT have the Tribunal expansion installed, trying to teleport to the Mournhold Royal Palace Reception Area won't work! Surprise! Time to buy Tribunal... (You won't be turned inside out or otherwise horribly killed, you will merely teleport to near Assarnatamat, which is a Daedric ruin halfway between Fortt Moonmoth and Ghostgate. Well, you might be horribly killed if you are level 1 and a Daedra sees you ;-)

Tribunal Installed

-Please be aware that using the ring circumvents the usual sequence of getting to Mournhold. You will know this is occurring when you are attacked by Dark Assassins, and your Journal is updated with information to go tell a Guard. You may want to abstain from using the ring to travel to Mournhold until you legitimately can do so on your own from Ebonheart. As far as I could tell, you could teleport back to Ebonheart using the mage in Mournhold, but the one in Ebonheart won't teleport you to Mournhold until the introductory quest is complete. Obviously, you can use the Ultimate Teleporter to get to and from Mournhold without restriction, but I don't know what effect this might have if you jump into doing stuff in Mournhold without going through the original quest sequence first. If you like to live dangerously, go for it, just back up a save game.

Help! I used the ring from the chest and now guards are killing me on sight!

-Please DO NOT use the Ultimate teleporter by taking it out of the chest and immediately dropping it on your character and porting somewhere near an NPC. Put it into your inventory first, close the chest, and THEN use it. What I think's happening is that the teleportation script goes off first, and when you appear, the ring is added to your inventory. NPC's nearby may see this as stealing, and since there is a very high monetary value on the Ultimate Teleporter (to prevent accidental selling) you'll get a huge bounty immediately, and probably be horribly killed. The moral of the story is: put the ring into your inventory, then equip it from there if you are having a bout of painful death. Unless you like that sort of thing, then go for it, by all means.


Here is a list of the 64 locations:

Sheogorad Region:
Dagon Fel - city
Mzuleft - Dwemer ruins
Sanctus Shrine - Tribunal shrine
Rotheran - Propylon chamber
Ald Daedroth - Daedra ruins
Ald Redaynia - tower
Big Head's Shack - quest location
Vas - tower

The Ashlands Region:
Ald'Ruhn - Redoran city
Maar Gan - city
Ghostgate - gateway to Red Mountain
Falasmaryon - Propylon chamber
Urshilaku Camp - Ashlander camp
Valenvaryon - Probpylon chamber
Dagoth Ur - Dagoth Ur's stronghold
Ft. Buckmoth - Imperial fort

West Gash Region:
Gnisis - city
Ald Velothi - outpost 
Khuul - city
Berandas - Propylon chamber
Andasreth - Propylon chamber
Arkngthunch-Sturdumz - Dwemer ruins
Koal Cave - Tribunal shrine
Ashinabi - smuggler cave

Bitter Coast Region:
Gnaar Mok - city
Caldera - city
Balmora - city
Hlormaren - Propylon chamber
Hla  Oad - city
Ft. Moonmoth - Imperial fort
Pelagiad - city
Seyda Neen - city

Ascadian Isles Region:
Ebon Heart - Imperial city
Vivec (Temple)
Vivec (Foreign Quarter)
Dren Plantation - quest location
Suran - city
Ald Sotha - Daedra ruins
Mzahnch - Dwemer ruins
Bal Fell - Daedra ruins

Molag Amur & Strongholds
Marandus - Propylon chamber
Telasero - Propylon chamber
Molag Mar - city
Mt. Kand - quest location
Erabenimsun Camp - Ashlander camp
Bal Isra - Redoran stronghold built here
Odai Plateau - Hlaalu stronghold built here
Uvirith's Grave - Telvani Stronghold built here

Grazelands Region:
Ahemmusa Camp - Ashlander camp
Tel Vos - city
Vos - city
Zainab Camp - Ashlander camp
Indoranyon - Propylon chamber
Falensarano - Propylon chamber
Dubdilla - quest location
Nchuleft - Dwemer ruins

East Coast Island and Mournhold Region:
Tel Mora - city
Tel Aruhn - city
Sadrith Mora - city
Tel Fyr - quest location
Tel Branora - city
Shrine of Azura - quest location
Holamayan - quest location
Mournhold Royal Palace Reception Area - Mournhold


*****************************************************************

     5. Original Script

*****************************************************************

Here is the orginal Utltimate Teleport text and script from the unkown author:

The Ultimate Teleporter allows you to teleport to 57 different locations around the world.  The item "Ultimate Teleporter" is added to the game.  To use it, just drop it on your picture as if to equip it.

In this mod, the item is on the table in the Seyda Neen Census and Excise Office next to Sellus Gravius. You can go back to get it from a previous save game or pick it up on your way out of the character generation process at the beginning of the game.

Since the only things modified are a new script and a new item, your old save games will work just fine with this mod.

Below is a copy of the script if you want to add it to your own mod rather than using this one.  Just create any new "misc item" and give it this script.


-- SNIP --
begin PSScript_UltimateTeleporter

short OnPCEquip
short button
short state

if ( OnPCEquip == 1 )
	Set state to 1
	Set OnPCEquip to 0
endif

if ( state == 0 )
	return
endif

if ( state == 1 )
	MessageBox "Choose area:" "Cancel" "Sheogorad..." "The Ashlands..." "West Gash..." "Bitter Coast..." "Ascadian Isles..." "Molag Amur & Strongholds..." "Grazelands..." "East Coast Islands..."
	Set state to 2
endif

if ( state == 2 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Cancel
		Set state to 0
	endif
	if ( button == 1 )
		; Sheogorad
		MessageBox "Choose your destination:" "Back..." "Dagon Fel" "Mzuleft" "Sanctus Shrine" "Rotheran" "Ald Daedroth" "Ald Redaynia"
		Set state to 3
	endif
	if ( button == 2 )
		; The Ashlands
		MessageBox "Choose your destination:" "Back..." "Ald'Ruhn" "Maar Gan" "Ghostgate" "Falasmaryon" "Urshilaku Camp" "Valenvaryon" "Dagoth Ur" "Ft. Buckmoth"
		Set state to 4
	endif
	if ( button == 3 )
		; West Gash
		MessageBox "Choose your destination:" "Back..." "Gnisis" "Ald Velothi" "Khuul" "Berandas" "Andasreth" "Arkngthunch-Sturdumz"
		Set state to 5
	endif
	if ( button == 4 )
		; Bitter Coast
		MessageBox "Choose your destination:" "Back..." "Gnaar Mok" "Caldera" "Balmora" "Hlormaren" "Hla Oad" "Ft. Moonmoth" "Pelagiad" "Seyda Neen"
		Set state to 6
	endif
	if ( button == 5 )
		; Ascadian Isles
		MessageBox "Choose your destination:" "Back..." "Ebon Heart" "Vivec (Temple)" "Vivec (Foreign Quarter)" "Dren Plantation" "Suran" "Ald Sotha" "Mzahnch" "Bal Fell"
		Set state to 7
	endif
	if ( button == 6 )
		; Molag Amur & Strongholds
		MessageBox "Choose your destination:" "Back..." "Marandus" "Telasero" "Molag Mar" "Mt. Kand" "Erabenimsun Camp" "Bal Isra" "Odai Plateau" "Uvirith's Grave"
		Set state to 8
	endif
	if ( button == 7 )
		; Grazelands
		MessageBox "Choose your destination:" "Back..." "Ahemmusa Camp" "Tel Vos" "Vos" "Zainab Camp" "Indoranyon" "Falensarano"
		Set state to 9
	endif
	if ( button == 8 )
		; East Coast Islands
		MessageBox "Choose your destination:" "Back..." "Tel Mora" "Tel Aruhn" "Sadrith Mora" "Tel Fyr" "Tel Branora" "Shrine of Azura" "Holamayan"
		Set state to 10
	endif
endif

; Sheogorad
if ( state == 3 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Dagon Fel
		MessageBox "Teleporting to Dagon Fel..."
		Player->Position, 58761 181776 555 80
		Set state to 0
	endif
	if ( button == 2 )
		; Mzuleft
		MessageBox "Teleporting to Mzuleft..."
		Player->Position, 54642 176963 1241 29
		Set state to 0
	endif
	if ( button == 3 )
		; Sanctus Shrine
		MessageBox "Teleporting to Sanctus Shrine..."
		Player->Position, 12202 173650 2016 22
		Set state to 0
	endif
	if ( button == 4 )
		; Rotheran
		MessageBox "Teleporting to Rotheran..."
		Player->Position, 53206 154027 1860 132
		Set state to 0
	endif
	if ( button == 5 )
		; Ald Daedroth
		MessageBox "Teleporting to Ald Daedroth..."
		Player->Position, 92214 167957 536 94
		Set state to 0
	endif
	if ( button == 6 )
		; Ald Redaynia
		MessageBox "Teleporting to Ald Redaynia..."
		Player->Position, -29894 179323 2320 270
		Set state to 0
	endif
	if ( button == 7 )
		;
		MessageBox "Teleporting to ..."
		Player->Position, 0 0 0 0
		Set state to 0
	endif
	if ( button == 8 )
		;
		MessageBox "Teleporting to ..."
		Player->Position, 0 0 0 0
		Set state to 0
	endif
endif

; The Ashlands
if ( state == 4 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Ald'Ruhn
		MessageBox "Teleporting to Ald'Ruhn..."
		Player->Position, -15577 52173 2118 0
		Set state to 0
	endif
	if ( button == 2 )
		; Maar Gan
		MessageBox "Teleporting to Maar Gan..."
		Player->Position, -22413 101807 1969 180
		Set state to 0
	endif
	if ( button == 3 )
		; Ghostgate
		MessageBox "Teleporting to Ghostgate..."
		Player->Position, 20752 38261 1274 0
		Set state to 0
	endif
	if ( button == 4 )
		; Falasmaryon
		MessageBox "Teleporting to Falasmaryon..."
		Player->Position, -11955 127599 1455 190
		Set state to 0
	endif
	if ( button == 5 )
		; Urshilaku Camp
		MessageBox "Teleporting to Urshilaku Camp..."
		Player->Position, -29011 150185 707 85
		Set state to 0
	endif
	if ( button == 6 )
		; Valenvaryon
		MessageBox "Teleporting to Valenvaryon..."
		Player->Position, -3682 154119 2354 180
		Set state to 0
	endif
	if ( button == 7 )
		; Dagoth Ur
		MessageBox "Teleporting to Dagoth Ur..."
		Player->Position, 19521 70401 11880 263
		Set state to 0
	endif
	if ( button == 8 )
		; Ft. Buckmoth
		MessageBox "Teleporting to Ft. Buckmoth..."
		Player->Position, -13360 43071 2615 90
		Set state to 0
	endif
endif

; West Gash
if ( state == 5 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Gnisis
		MessageBox "Teleporting to Gnisis..."
		Player->Position, -86336 92029 1028 180
		Set state to 0
	endif
	if ( button == 2 )
		; Ald Velothi
		MessageBox "Teleporting to Ald Velothi..."
		Player->Position, -84298 123589 1402 330
		Set state to 0
	endif
	if ( button == 3 )
		; Khuul
		MessageBox "Teleporting to Khuul..."
		Player->Position, -66297 137851 536 327
		Set state to 0
	endif
	if ( button == 4 )
		; Berandas
		MessageBox "Teleporting to Berandas..."
		Player->Position, -77788 76069 2351 344
		Set state to 0
	endif
	if ( button == 5 )
		; Andasreth
		MessageBox "Teleporting to Andasreth..."
		Player->Position, -68248 47807 1808 160
		Set state to 0
	endif
	if ( button == 6 )
		; Arkngthunch-Sturdumz
		MessageBox "Teleporting to Arkngthunch-Sturdumz..."
		Player->Position, -103644 116298 2261 183
		Set state to 0
	endif
	if ( button == 7 )
		;
		MessageBox "Teleporting to ..."
		Player->Position, 0 0 0 0
		Set state to 0
	endif
	if ( button == 8 )
		;
		MessageBox "Teleporting to ..."
		Player->Position, 0 0 0 0
		Set state to 0
	endif
endif

; Bitter Coast
if ( state == 6 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Gnaar Mok
		MessageBox "Teleporting to Gnaar Mok..."
		Player->Position, -58679 26486 190 270
		Set state to 0
	endif
	if ( button == 2 )
		; Caldera
		MessageBox "Teleporting to Caldera..."
		Player->Position, -11293 20011 1360 124
		Set state to 0
	endif
	if ( button == 3 )
		; Balmora
		MessageBox "Teleporting to Balmora..."
		Player->Position, -22290 -18786 485 0
		Set state to 0
	endif
	if ( button == 4 )
		; Hlormaren
		MessageBox "Teleporting to Hlormaren..."
		Player->Position, -45093 -4929 2386 0
		Set state to 0
	endif
	if ( button == 5 )
		; Hla Oad
		MessageBox "Teleporting to Hla Oad..."
		Player->Position, -48494 -39754 188 80
		Set state to 0
	endif
	if ( button == 6 )
		; Ft. Moonmoth
		MessageBox "Teleporting to Ft. Moonmoth..."
		Player->Position, -5075 -18578 1073 180
		Set state to 0
	endif
	if ( button == 7 )
		; Pelagiad
		MessageBox "Teleporting to Pelagiad..."
		Player->Position, 5738 -56059 1795 90
		Set state to 0
	endif
	if ( button == 8 )
		; Seyda Neen
		MessageBox "Teleporting to Seyda Neen..."
		Player->Position, -8681 -70139 923 23
		Set state to 0
	endif
endif

; Ascadian Isles
if ( state == 7 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Ebonheart
		MessageBox "Teleporting to Ebonheart..."
		Player->Position, 10290 -100626 1472 90
		Set state to 0
	endif
	if ( button == 2 )
		; Vivec (Temple)
		MessageBox "Teleporting to Vivec (Temple)..."
		Player->Position, 32879 -99093 1168 0
		Set state to 0
	endif
	if ( button == 3 )
		; Vivec (Foreign Quarter)
		MessageBox "Teleporting to Vivec (Foreign Quarter)..."
		Player->Position, 29869 -78507 3105 0
		Set state to 0
	endif
	if ( button == 4 )
		; Dren Plantation
		MessageBox "Teleporting to Dren Plantation..."
		Player->Position, 22169 -55319 755 118
		Set state to 0
	endif
	if ( button == 5 )
		; Suran
		MessageBox "Teleporting to Suran..."
		Player->Position, 53162 -48230 984 180
		Set state to 0
	endif
	if ( button == 6 )
		; Ald Sotha
		MessageBox "Teleporting to Ald Sotha..."
		Player->Position, 55618 -73029 107 148
		Set state to 0
	endif
	if ( button == 7 )
		; Mzahnch
		MessageBox "Teleporting to Mzahnch..."
		Player->Position, 71168 -74304 384 0
		Set state to 0
	endif
	if ( button == 8 )
		; Bal Fell
		MessageBox "Teleporting to Bal Fell..."
		Player->Position, 73315 -96084 777 0
		Set state to 0
	endif
endif

; Molag Amur & Strongholds
if ( state == 8 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Marandus
		MessageBox "Teleporting to Marandus..."
		Player->Position, 37083 -20283 1454 218
		Set state to 0
	endif
	if ( button == 2 )
		; Telasero
		MessageBox "Teleporting to Telasero..."
		Player->Position, 77330 -52928 1444 223
		Set state to 0
	endif
	if ( button == 3 )
		; Molag Mar
		MessageBox "Teleporting to Molag Mar..."
		Player->Position, 110666 -61665 2178 0
		Set state to 0
	endif
	if ( button == 4 )
		; Mt. Kand
		MessageBox "Teleporting to Mt. Kand..."
		Player->Position, 93713 -39313 6424 45
		Set state to 0
	endif
	if ( button == 5 )
		; Erabenimsun Camp
		MessageBox "Teleporting to Erabenimsun Camp..."
		Player->Position, 109740 -3908 634 282
		Set state to 0
	endif
	if ( button == 6 )
		; Bal Isra
		MessageBox "Teleporting to Bal Isra..."
		Player->Position, -35684 79406 1783 50
		Set state to 0
	endif
	if ( button == 7 )
		; Odai Plateau
		MessageBox "Teleporting to Odai Plateau..."
		Player->Position, -35555 -37052 1906 0
		Set state to 0
	endif
	if ( button == 8 )
		; Uvirith's Grave
		MessageBox "Teleporting to Uvirith's Grave..."
		Player->Position, 85814 11267 1896 132
		Set state to 0
	endif
endif

; Grazelands
if ( state == 9 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Ahemmusa Camp
		MessageBox "Teleporting to Ahemmusa Camp..."
		Player->Position, 94264 134918 951 137
		Set state to 0
	endif
	if ( button == 2 )
		; Tel Vos
		MessageBox "Teleporting to Tel Vos..."
		Player->Position, 89021 117944 3252 280
		Set state to 0
	endif
	if ( button == 3 )
		; Vos
		MessageBox "Teleporting to Vos..."
		Player->Position, 100664 114037 255 222
		Set state to 0
	endif
	if ( button == 4 )
		; Zainab Camp
		MessageBox "Teleporting to Zainab Camp..."
		Player->Position, 78195 84681 885 247
		Set state to 0
	endif
	if ( button == 5 )
		; Indoranyon
		MessageBox "Teleporting to Indoranyon..."
		Player->Position, 119528 75714 1364 353
		Set state to 0
	endif
	if ( button == 6 )
		; Falensarano
		MessageBox "Teleporting to Falensarano..."
		Player->Position, 76153 51408 1683 0
		Set state to 0
	endif
	if ( button == 7 )
		; 
		MessageBox "Teleporting to ..."
		Player->Position, 0 0 0 0
		Set state to 0
	endif
	if ( button == 8 )
		; 
		MessageBox "Teleporting to ..."
		Player->Position, 0 0 0 0
		Set state to 0
	endif
endif

; East Coast Islands
if ( state == 10 )
	Set button to GetButtonPressed
	if ( button == 0 )
		; Back
		Set state to 1
	endif
	if ( button == 1 )
		; Tel Mora
		MessageBox "Teleporting to Tel Mora..."
		Player->Position, 106928 117172 263 34
		Set state to 0
	endif
	if ( button == 2 )
		; Tel Aruhn
		MessageBox "Teleporting to Tel Aruhn..."
		Player->Position, 123304 41164 182 52
		Set state to 0
	endif
	if ( button == 3 )
		; Sadrith Mora
		MessageBox "Teleporting to Sadrith Mora..."
		Player->Position, 141878 38637 338 177
		Set state to 0
	endif
	if ( button == 4 )
		; Tel Fyr
		MessageBox "Teleporting to Tel Fyr..."
		Player->Position, 124384 15858 492 0
		Set state to 0
	endif
	if ( button == 5 )
		; Tel Branora
		MessageBox "Teleporting to Tel Branora..."
		Player->Position, 119153 -102116 160 159
		Set state to 0
	endif
	if ( button == 6 )
		; Shrine of Azura
		MessageBox "Teleporting to Shrine of Azura..."
		Player->Position, 161720 -61790 1665 102
		Set state to 0
	endif
	if ( button == 7 )
		; Holamayan
		MessageBox "Teleporting to Holamayan..."
		Player->Position, 160255 -36135 168 0
		Set state to 0
	endif
	if ( button == 8 )
		;
		MessageBox "Teleporting to ..."
		Player->Position, 0 0 0 0
		Set state to 0
	endif
endif

end
-- SNIP --
