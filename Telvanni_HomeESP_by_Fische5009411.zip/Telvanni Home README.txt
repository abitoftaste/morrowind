Telvanni Home README

=====================================================

This mod adds a telvanni housepod to sadrith mora for the player to live in.
Its located on a hill by the docks.it has all the basics for a house mod, bed storage ECT.


========================
How to install
========================

just copy the .ESP fle into your morrowind directory

then open the game and click "DATA FIlES" and check off the "telvanni home.ESP" box. 

Go to sadrith mora, fine the POD and enjoy the mod!





===============================================
Credits and Useage 			      
===============================================

Credits

Bethesda, for making the great morrowind game

fischer500 (ME) for putting the house together.



------------------------
useage
------------------------


You can use this mod for whatever you want, but tell me AND give credit where it is due.